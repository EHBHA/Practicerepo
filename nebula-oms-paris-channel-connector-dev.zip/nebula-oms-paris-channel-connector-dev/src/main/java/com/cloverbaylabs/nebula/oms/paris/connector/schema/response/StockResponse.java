package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import java.util.List;

import com.cloverbaylabs.nebula.oms.paris.connector.schema.stock.Stock;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class StockResponse {
    private List<Stock> stock;
}
