package com.cloverbaylabs.nebula.oms.paris.connector.core.service.impl;

import java.util.HashMap;
import java.util.Map;

import com.cloverbaylabs.nebula.oms.paris.connector.core.config.ApiAction;
import com.cloverbaylabs.nebula.oms.paris.connector.core.facade.MarketplaceConnectorFacade;
import com.cloverbaylabs.nebula.oms.paris.connector.core.service.ProductService;
import com.cloverbaylabs.nebula.oms.paris.connector.core.util.JsonUtil;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.CreateProduct;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.Price;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.UpdateProduct;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.CreateProductResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.PaginatedResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ProductAttribute;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ProductDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ApiAction apiAction;
    private final MarketplaceConnectorFacade facade;
    private final JsonUtil jsonUtil;
    private final MediaType mediaType = MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON_VALUE);

    @SuppressWarnings("unchecked")
    @Override
    public PaginatedResponse<ProductDTO> getFamilies(String businessGroupId, String tenantId, Integer limit, Integer offset) {

        Map<String, Object> params = new HashMap<>();
        params.put("offset", offset);
        params.put("limit", limit);
        
        String url = facade.buildUrlWithParams(
                apiAction.getProductFamilies(),
                params);
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return (PaginatedResponse<ProductDTO>) facade.marketplaceApiExchange(conn, null, PaginatedResponse.class);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PaginatedResponse<ProductAttribute> getAttributesByProduct(
            String businessGroupId, String tenantId,
            String familyId, Integer limit, Integer offset) {

        Map<String, Object> params = new HashMap<>();
        params.put("offset", offset);
        params.put("limit", limit);

        String url = facade.buildUrlWithParams(
                apiAction.getAttributesByProduct().replace("{familyId}", familyId),
                params);
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return (PaginatedResponse<ProductAttribute>) facade.marketplaceApiExchange(conn, null, PaginatedResponse.class); // Fixed incorrect generic type
    }

    @SuppressWarnings("unchecked")
    @Override
    public PaginatedResponse<ProductAttribute> getAttributesByVariant(
            String businessGroupId, String tenantId,
            String familyId, Integer limit, Integer offset) {

        Map<String, Object> params = new HashMap<>();
        params.put("offset", offset);
        params.put("limit", limit);

        String url = facade.buildUrlWithParams(
                apiAction.getAttributesByVariant().replace("{familyId}", familyId),
                params);
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return (PaginatedResponse<ProductAttribute>) facade.marketplaceApiExchange(conn, null, PaginatedResponse.class); // Fixed incorrect generic type
    }

    @Override
    public CreateProductResponse createProduct(String businessGroupId, String tenantId, CreateProduct createProduct) {

        String url = apiAction.getCreateProduct();
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.POST)
                .endpointUrl(url).build();

        String requestBodyJson = jsonUtil.convertToString(createProduct);
        RequestBody requestBody = RequestBody.create(requestBodyJson, mediaType);

        return facade.marketplaceApiExchange(conn, requestBody, CreateProductResponse.class);
    }

    @Override
    public CreateProductResponse updateProduct(String businessGroupId, String tenantId,
                                               UpdateProduct updateProduct, String id) {
        String url = apiAction.getUpdateProduct().replace("{id}", id);
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.PATCH)
                .endpointUrl(url).build();

        String requestBodyJson = jsonUtil.convertToString(updateProduct);
        RequestBody requestBody = RequestBody.create(requestBodyJson, mediaType);

        return facade.marketplaceApiExchange(conn, requestBody, CreateProductResponse.class);
    }

    @Override
    public CreateProductResponse updatePrice(String businessGroupId, String tenantId,
                                             Price price, String sku) {
        String url = apiAction.getBookPrice().replace("{sku}", sku);
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.POST)
                .endpointUrl(url).build();

        String requestBodyJson = jsonUtil.convertToString(price);
        RequestBody requestBody = RequestBody.create(requestBodyJson, mediaType);

        return facade.marketplaceApiExchange(conn, requestBody, CreateProductResponse.class);
    }

    @Override
    public PaginatedResponse<ProductDTO> getAllProducts(String businessGroupId, String tenantId, Integer limit, Integer offset) {
        return null;
    }

    @Override
    public PaginatedResponse<ProductDTO> getCategories(String businessGroupId, String tenantId, String familyId, Integer limit, Integer offset) {
        return null;
    }

}
