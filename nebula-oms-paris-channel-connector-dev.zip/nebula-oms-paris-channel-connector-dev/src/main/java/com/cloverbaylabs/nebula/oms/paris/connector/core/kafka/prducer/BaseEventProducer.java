package com.cloverbaylabs.nebula.oms.paris.connector.core.kafka.prducer;

public abstract class BaseEventProducer {
    // @Autowired
    // protected KafkaTemplate<String, Object> kafkaTemplateProducer;

    // @Autowired
    // private JsonUtil jsonUtil;

    // @SneakyThrows
    // public Event getEventPayload(String businessGroupId,
    //                              String tenantId,
    //                              EntityType entityType,
    //                              EventType eventType,
    //                              Object msg) {

    //     return getEventDetail(businessGroupId, tenantId, entityType,
    //             eventType, msg);
    // }

    // public Event getEventDetail(String businessGroupId,
    //                             String tenantId,
    //                             EntityType entityType,
    //                             EventType eventType,
    //                             Object msg) {
    //     var eventMsg = jsonUtil.convertToString(msg);
    //     return Event.builder()
    //             .id(UUID.randomUUID().toString())
    //             .source(EventSource.NEBULA.name())
    //             .resources(EventResource.PARIS_CONNECTOR.name())
    //             .time(Instant.now().toString())
    //             .detailType("EVENT")
    //             .detail(EventDetail.builder()
    //                     .entityType(entityType.toString())
    //                     .eventType(eventType.toString())
    //                     .businessGrpId(businessGroupId)
    //                     .tenantId(tenantId)
    //                     .mimeType(MediaType.APPLICATION_JSON_VALUE)
    //                     .message(eventMsg)
    //                     .version("v1")
    //                     .build())
    //             .build();
    // }

    // @SneakyThrows
    // public void publish(String topic, Object msg) {
    //     try {
    //         kafkaTemplateProducer.send(topic, msg).get();
    //         log.info("EVENT PUBLISHED TO TOPIC: {} MESSAGE: {}", topic, msg);
    //     } catch (Exception e) {
    //         log.error("FAILED TO PUBLISH EVENT TO TOPIC: {} MESSAGE: {}", topic, msg, e);
    //         throw new RuntimeException(String.format("Failed to publish event to topic: %s", topic));
    //     }
    // }
}
