package com.cloverbaylabs.nebula.oms.paris.connector.core.kafka.prducer;

import org.springframework.stereotype.Component;

@Component
public class ProductEventProducer extends BaseEventProducer {

    // @Autowired
    // private EventTopics eventTopic;

//    public void publishProductCreate(String businessGroupId,
//                                     String tenantId,
//                                     Object eventMsg) {
//        var event = getEventPayload(businessGroupId,
//                tenantId, EntityType.PRODUCT,
//                EventType.PRODUCT_CREATED, eventMsg);
//        publish(eventTopic.getProductCreated(), event);
//    }
//
//    public void publishProductUpdated(String businessGroupId,
//                                      String tenantId,
//                                      Object eventMsg) {
//        var event = getEventPayload(businessGroupId,
//                tenantId, EntityType.PRODUCT,
//                EventType.PRODUCT_UPDATED, eventMsg);
//        publish(eventTopic.getProductUpdated(), event);
//    }
//
//    public void publishProductQcChange(String businessGroupId,
//                                       String tenantId,
//                                       Object eventMsg) {
//        var event = getEventPayload(businessGroupId,
//                tenantId, EntityType.PRODUCT,
//                EventType.PRODUCT_QC_STATUS_UPDATE, eventMsg);
//        publish(eventTopic.getProductQcStatusChanged(), event);
//    }
}


