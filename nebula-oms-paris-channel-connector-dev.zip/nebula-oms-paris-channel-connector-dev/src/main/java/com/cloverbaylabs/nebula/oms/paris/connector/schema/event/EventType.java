package com.cloverbaylabs.nebula.oms.paris.connector.schema.event;

public enum EventType {

    ORDER_CREATE

}
