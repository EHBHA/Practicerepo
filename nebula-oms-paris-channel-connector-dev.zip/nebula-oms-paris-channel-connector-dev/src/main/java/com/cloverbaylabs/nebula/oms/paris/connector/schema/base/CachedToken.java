package com.cloverbaylabs.nebula.oms.paris.connector.schema.base;


import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class CachedToken {
        private final String token;
//        private final TimeUnit expirationTime;

}
