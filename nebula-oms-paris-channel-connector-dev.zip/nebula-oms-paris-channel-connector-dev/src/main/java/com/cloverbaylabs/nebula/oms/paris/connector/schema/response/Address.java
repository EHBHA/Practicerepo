package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Address {
    private String id;
    private String firstName;
    private String lastName;
    private String address1;
    private String address2;
    private String address3;
    private String city;
    private String stateCode;
    private String countryCode;
    private String phone;
    private String communaCode;

}
