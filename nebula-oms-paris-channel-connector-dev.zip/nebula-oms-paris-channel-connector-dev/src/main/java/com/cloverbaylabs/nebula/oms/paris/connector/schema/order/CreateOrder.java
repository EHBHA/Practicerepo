package com.cloverbaylabs.nebula.oms.paris.connector.schema.order;

import java.util.List;

import com.cloverbaylabs.framework.utilities.constant.ValidationMessages;
import com.cloverbaylabs.framework.utilities.validation.annotation.EnumValue;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.enums.OrderStatus;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CreateOrder {

    @NotBlank(message = "sellerId" + ValidationMessages.INVALID_MISSING)
    private String sellerId;
    @NotBlank(message = "categoryCode" + ValidationMessages.INVALID_MISSING)
    private String categoryCode;
    private List<ListItem> items;
    @EnumValue(enumClass = OrderStatus.class)
    private String orderStatus;
    private int limit;


    @Getter
    @Setter
    @NoArgsConstructor
    public static class ListItem {
        private String sku;
        private int status;
    }
}
