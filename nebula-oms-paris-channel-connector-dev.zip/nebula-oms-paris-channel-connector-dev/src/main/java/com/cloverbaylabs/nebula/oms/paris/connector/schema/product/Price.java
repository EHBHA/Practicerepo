package com.cloverbaylabs.nebula.oms.paris.connector.schema.product;

import java.time.OffsetDateTime;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Price {

    public Double value;
    public String storePrice;
    public String type;
    public OffsetDateTime showFrom;
    public OffsetDateTime showTo;
}
