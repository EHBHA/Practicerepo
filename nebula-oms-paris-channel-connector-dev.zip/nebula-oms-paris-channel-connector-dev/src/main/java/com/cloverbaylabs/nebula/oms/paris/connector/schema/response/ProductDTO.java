package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@NoArgsConstructor
public class ProductDTO {
    private String id;
    private String name;
}
