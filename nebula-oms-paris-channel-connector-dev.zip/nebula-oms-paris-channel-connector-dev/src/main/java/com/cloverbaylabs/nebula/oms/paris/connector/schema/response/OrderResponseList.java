package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class OrderResponseList {
    private List<Order> data;
    private int count;
}

