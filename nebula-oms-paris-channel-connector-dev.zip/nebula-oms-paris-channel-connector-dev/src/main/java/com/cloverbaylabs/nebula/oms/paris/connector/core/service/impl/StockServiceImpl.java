package com.cloverbaylabs.nebula.oms.paris.connector.core.service.impl;

import java.util.HashMap;
import java.util.Map;

import com.cloverbaylabs.nebula.oms.paris.connector.core.config.ApiAction;
import com.cloverbaylabs.nebula.oms.paris.connector.core.facade.MarketplaceConnectorFacade;
import com.cloverbaylabs.nebula.oms.paris.connector.core.service.StockService;
import com.cloverbaylabs.nebula.oms.paris.connector.core.util.JsonUtil;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.GetStock;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.PaginatedResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.StockResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.stock.CreateStock;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class StockServiceImpl implements StockService {

    private final ApiAction apiAction;
    private final MarketplaceConnectorFacade facade;
    private final JsonUtil jsonUtil;
    private final MediaType mediaType = MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON_VALUE);

    @Override
    public StockResponse createStock(String businessGroupId, String tenantId, CreateStock createStock) {
        String url = apiAction.getCreateStock();
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.POST)
                .endpointUrl(url).build();

        String requestBodyJson = jsonUtil.convertToString(createStock);
        RequestBody requestBody = RequestBody.create(requestBodyJson, mediaType);

        return facade.marketplaceApiExchange(conn, requestBody, StockResponse.class);
    }

    @Override
    public StockResponse createStockWithSkuSeller(String businessGroupId, String tenantId, CreateStock createStock) {
        String url = apiAction.getCreateStockWithSkuSeller();
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.POST)
                .endpointUrl(url).build();

        String requestBodyJson = jsonUtil.convertToString(createStock);
        RequestBody requestBody = RequestBody.create(requestBodyJson, mediaType);

        return facade.marketplaceApiExchange(conn, requestBody, StockResponse.class);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PaginatedResponse<GetStock> getAllStock(String businessGroupId, String tenantId, String sku, String skuParent,
                                                   String skuSeller, Boolean intangibles, Boolean withStock, Boolean groupByParent,
                                                   Integer offset, Integer limit) {

        Map<String, Object> params = new HashMap<>();
        params.put("offset", offset);
        params.put("limit", limit);

        if (sku != null) {
            params.put("sku", sku);
        }
        if (skuParent != null) {
            params.put("skuParent", skuParent);
        }
        if (skuSeller != null) {
            params.put("skuSeller", skuSeller);
        }
        if (intangibles != null) {
            params.put("intangibles", intangibles);
        }
        if (withStock != null) {
            params.put("withStock", withStock);
        }
        if (groupByParent != null) {
            params.put("groupByParent", groupByParent);
        }

        String url = facade.buildUrlWithParams(
                apiAction.getShipmentLabel(), params);
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return (PaginatedResponse<GetStock>) facade.marketplaceApiExchange(conn, null, PaginatedResponse.class);
    }
}
