package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GetStock {
    public String sku;
    public int quantity;
    public boolean isFulfillment;
    public int size;
    public String title;
    public String warehouseName;
    public String updatedAt;
    public int availableStock;
    public int securityStock;
    public boolean active;

    @JsonProperty("sku_seller")
    public String skuSeller;

    @JsonProperty("intangible_type")
    public String intangibleType;

    public int count;
}

