package com.cloverbaylabs.nebula.oms.paris.connector.api.controller;

import com.cloverbaylabs.nebula.oms.paris.connector.api.aspect.Scope;
import com.cloverbaylabs.nebula.oms.paris.connector.api.aspect.TrackTime;
import com.cloverbaylabs.nebula.oms.paris.connector.core.service.StockService;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.GetStock;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.PaginatedResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.StockResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.stock.CreateStock;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.BUSINESS_GROUP_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.CLIENT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TENANT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TRACE_ID;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/stock")
@Tag(name = "STOCK CONTROLLER",
        description = "APIs exposed to perform stock operations on paris marketplace")
public class StockController {

    private StockService stockService;

    @TrackTime
    @Operation(summary = "Create/Update stock ", method = "POST")
    @Scope("ne:oms:paris:stock:create")
    @PostMapping("v1")
    public ResponseEntity<StockResponse> createUpdateStock(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody @Valid CreateStock createStock) {
        return ResponseEntity
                .ok(stockService.createStock(businessGroupId, tenantId, createStock));
    }

    @TrackTime
    @Operation(summary = "Create/Update stock with sku-seller", method = "POST")
    @Scope("ne:oms:paris:stock:create")
    @PostMapping("v1/sku-seller")
    public ResponseEntity<StockResponse> createUpdateStockWithSkuSeller (
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody @Valid CreateStock createStock) {
        return ResponseEntity
                .ok(stockService.createStockWithSkuSeller(businessGroupId, tenantId, createStock));
    }

    @TrackTime
    @Operation(summary = "Get all stock", method = "GET")
    @Scope("ne:oms:paris:stock:get:all")
    @GetMapping("v1/all")
    public ResponseEntity<PaginatedResponse<GetStock>> getALlOrders(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(required = false) String sku,
            @RequestParam(required = false) String skuParent,
            @RequestParam(required = false) String skuSeller,
            @RequestParam(required = false) Boolean intangibles,
            @RequestParam(required = false) Boolean withStock,
            @RequestParam(required = false) Boolean groupByParent,
            @RequestParam(name = "offset", defaultValue = "0") Integer offset,
            @RequestParam(name = "limit", defaultValue = "10") Integer limit){
        return ResponseEntity
                .ok(stockService.getAllStock(businessGroupId, tenantId, sku, skuParent, skuSeller,
                        intangibles, withStock, groupByParent, offset, limit));
    }
}
