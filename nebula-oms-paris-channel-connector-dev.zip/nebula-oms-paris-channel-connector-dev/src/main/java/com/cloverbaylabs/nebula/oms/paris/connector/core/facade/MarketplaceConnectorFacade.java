package com.cloverbaylabs.nebula.oms.paris.connector.core.facade;

import java.util.Map;

import com.cloverbaylabs.nebula.oms.paris.connector.schema.base.ConnectorDetails;
import okhttp3.RequestBody;

public interface MarketplaceConnectorFacade {
    <T> T marketplaceApiExchange(ConnectorDetails connectorDetails,
                                        RequestBody requestBody, Class<T> responseClass);

    String buildUrlWithParams(String baseUrl, Map<String, ?> params);
}
