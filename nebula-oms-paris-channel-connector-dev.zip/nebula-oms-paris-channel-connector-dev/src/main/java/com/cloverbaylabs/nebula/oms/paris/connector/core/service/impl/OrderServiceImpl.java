package com.cloverbaylabs.nebula.oms.paris.connector.core.service.impl;

import java.util.List;

import com.cloverbaylabs.nebula.oms.paris.connector.core.config.ApiAction;
import com.cloverbaylabs.nebula.oms.paris.connector.core.facade.MarketplaceConnectorFacade;
import com.cloverbaylabs.nebula.oms.paris.connector.core.service.OrderService;
import com.cloverbaylabs.nebula.oms.paris.connector.core.util.JsonUtil;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.order.CreateOrder;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ListResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.OrderResponseList;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ShipmentLabel;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {
    
    private final ApiAction apiAction;
    private final MarketplaceConnectorFacade facade;
    private final JsonUtil jsonUtil;
    private final MediaType mediaType = MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON_VALUE);


    @Override
    public OrderResponseList getAllOrders(String businessGroupId, String tenantId, Integer offset, Integer limit) {
        String url = apiAction.getAllOrders();
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return facade.marketplaceApiExchange(conn, null, OrderResponseList.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Integer> createOrder(String businessGroupId, String tenantId, CreateOrder createOrder) {
        String url = apiAction.getCreateOrder();
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.POST)
                .endpointUrl(url).build();

        String requestBodyJson = jsonUtil.convertToString(createOrder);
        RequestBody requestBody = RequestBody.create(requestBodyJson, mediaType);

        return facade.marketplaceApiExchange(conn, requestBody, List.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    public ListResponse<ShipmentLabel> printLabel(String businessGroupId, String tenantId, String labelId) {
        String url = apiAction.getShipmentLabel().replace("{labelId}", labelId);
        ConnectorDetails conn = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return (ListResponse<ShipmentLabel>) facade.marketplaceApiExchange(conn, null, ListResponse.class);
    }
}
