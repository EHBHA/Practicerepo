package com.cloverbaylabs.nebula.oms.paris.connector.schema.product;


import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class CreateProduct extends UpdateProduct {

    private List<Price> prices;

}
