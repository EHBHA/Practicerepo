package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SubOrder {
    private int id;
    private int facilityConfigId;
    private String orderId;
    private String subOrderNumber;
    private int statusId;
    private String carrier;
    private String trackingNumber;
    private String labelUrl;
    private String labelId;
    private String deliveryExternalId;
    private String dispatchDate;
    private String arrivalDate;
    private String arrivalDateEnd;
    private String effectiveArrivalDate;
    private String effectiveDispatchDate;
    private String effectiveManifestDate;
    private String lastNotificationId;
    private String fulfillment;
    private String centryId;
    private String cost;
    private String updatedAt;
    private String oldShipmentId;
    private int carrierSystemId;
    private List<Object> tracking;
    private AdditionalAttributes deliveryOption;
    private AdditionalAttributes status;
    private Address shippingAddress;
    private List<Item> items;

}

