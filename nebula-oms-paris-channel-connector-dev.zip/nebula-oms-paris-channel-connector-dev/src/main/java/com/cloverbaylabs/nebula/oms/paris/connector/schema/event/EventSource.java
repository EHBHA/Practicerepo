package com.cloverbaylabs.nebula.oms.paris.connector.schema.event;

public enum EventSource {
    NEBULA
}
