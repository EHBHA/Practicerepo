package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Item {
    private String id;
    private String sku;
    private String name;
    private String sellerId;
    private String jdaSku;
    private String basePrice;
    private String grossPrice;
    private int priceAfterDiscounts;
    private String taxRate;
    private String size;
    private String sellerSku;
    private int position;
    private String subOrderNumber;
    private String cancellationReasonId;
    private int statusId;
    private String imagePath;
    private String itemSize;
    private String orderId;
    private String userId;
    private String category;
    private String categoryId;
    private AdditionalAttributes status;
    private String cancellationReason;

}

