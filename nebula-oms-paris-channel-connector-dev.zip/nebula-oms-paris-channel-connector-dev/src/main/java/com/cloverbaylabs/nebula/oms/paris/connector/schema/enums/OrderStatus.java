package com.cloverbaylabs.nebula.oms.paris.connector.schema.enums;

import lombok.Getter;

@Getter
public enum OrderStatus {
    delivered,
    ready_to_ship,
    awaiting_fullfillment,
    cancelled
}
