package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ProductAttribute {

    private String id;
    private String name;
    private String type;
    private List<AttributeOption> attributeOptions;
    private List<FamilyAttribute> familyAttributes;

    @Getter
    @Setter
    @NoArgsConstructor
    public static class AttributeOption {
        private String id;
        private String name;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class FamilyAttribute {
        private String id;
        private AttributeValidation attributeValidation;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class AttributeValidation {
        private String id;
        private boolean isRequired;
        private int length;
    }


}
