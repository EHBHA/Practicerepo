package com.cloverbaylabs.nebula.oms.paris.connector.core.kafka;

import org.springframework.context.annotation.Configuration;

@Configuration
// @EnableKafka
public class KafkaProducerConfig {

    // /**
    //  *
    //  */
    // @Value("${spring.kafka.bootstrap-servers}")
    // public String bootstrapAddress;

    // /**
    //  *
    //  * @return
    //  */
    // public Map<String, Object> producerConfig() {
    //     Map<String, Object> configProps = new HashMap<>();
    //     configProps.put(
    //             ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
    //             bootstrapAddress);
    //     configProps.put(
    //             ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
    //             StringSerializer.class);
    //     configProps.put(
    //             ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
    //             JsonSerializer.class);

    //     return configProps;
    // }
    // @Bean
    // public ProducerFactory<String, Object> producerFactory() {
    //     return new DefaultKafkaProducerFactory<>(producerConfig());
    // }

    // @Bean
    // public KafkaTemplate<String, Object> kafkaTemplateProducer() {
    //     return new KafkaTemplate<>(producerFactory());
    // }
}

