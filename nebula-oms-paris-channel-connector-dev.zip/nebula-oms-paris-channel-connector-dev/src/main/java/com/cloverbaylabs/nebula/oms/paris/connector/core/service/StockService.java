package com.cloverbaylabs.nebula.oms.paris.connector.core.service;

import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.GetStock;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.PaginatedResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.StockResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.stock.CreateStock;

public interface StockService {
    StockResponse createStock(String businessGroupId, String tenantId, CreateStock createStock);

    StockResponse createStockWithSkuSeller(String businessGroupId, String tenantId, CreateStock createStock);

    PaginatedResponse<GetStock> getAllStock(String businessGroupId, String tenantId, String sku,
                                            String skuParent, String skuSeller, Boolean intangibles,
                                            Boolean withStock, Boolean groupByParent, Integer offset, Integer limit);
}
