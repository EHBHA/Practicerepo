package com.cloverbaylabs.nebula.oms.paris.connector.api.controller;

import java.util.List;

import com.cloverbaylabs.nebula.oms.paris.connector.api.aspect.Scope;
import com.cloverbaylabs.nebula.oms.paris.connector.api.aspect.TrackTime;
import com.cloverbaylabs.nebula.oms.paris.connector.core.service.OrderService;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.order.CreateOrder;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ListResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.OrderResponseList;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ShipmentLabel;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.BUSINESS_GROUP_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.CLIENT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TENANT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TRACE_ID;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/orders")
@Tag(name = "ORDER CONTROLLER",
        description = "APIs exposed to perform orders on paris marketplace")
public class OrderController {

    private final OrderService orderService;

    @TrackTime
    @Operation(summary = "Get all orders", method = "GET")
    @Scope("ne:oms:paris:orders:get:all")
    @GetMapping("v1/all")
    public ResponseEntity<OrderResponseList> getALlOrders(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(name = "offset", defaultValue = "0") Integer offset,
            @RequestParam(name = "limit", defaultValue = "10") Integer limit) {
        return ResponseEntity
                .ok(orderService.getAllOrders(businessGroupId, tenantId,
                        offset, limit));
    }

    @TrackTime
    @Operation(summary = "Create Order", method = "POST")
    @Scope("ne:oms:paris:orders:create")
    @PostMapping("v1")
    public ResponseEntity<List<Integer>> createOrder(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody @Valid CreateOrder createOrder) {
        return ResponseEntity
                .ok(orderService.createOrder(businessGroupId, tenantId, createOrder));
    }

    @TrackTime
    @Operation(summary = "Print Label", method = "GET")
    @Scope("ne:oms:paris:orders:label")
    @GetMapping("/v1/label/{labelId}")
    public ResponseEntity<ListResponse<ShipmentLabel>> printLabel(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @PathVariable("labelId") String labelId) {
        return ResponseEntity
                .ok(orderService.printLabel(businessGroupId, tenantId, labelId));
    }



}
