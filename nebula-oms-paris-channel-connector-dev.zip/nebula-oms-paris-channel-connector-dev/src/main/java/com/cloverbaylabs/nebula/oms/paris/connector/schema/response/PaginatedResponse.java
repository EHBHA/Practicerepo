package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PaginatedResponse <T> {
    private PageDTO paging;
    private List<Links> links;
    private List<T> results;



    @Getter
    @Setter
    @NoArgsConstructor
    public static class PageDTO {
        private Integer total;
        private Integer limit;
        private Integer offset;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class Links {
        private String rel;
        private String href;
    }



}
