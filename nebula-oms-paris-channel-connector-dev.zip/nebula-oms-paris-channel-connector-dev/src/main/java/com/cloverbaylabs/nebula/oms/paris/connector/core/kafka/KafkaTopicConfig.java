package com.cloverbaylabs.nebula.oms.paris.connector.core.kafka;

import org.springframework.context.annotation.Configuration;

@Configuration
public class KafkaTopicConfig{

    // @Value("${spring.kafka.bootstrap-servers}")
    // private String bootstrapAddress;

    // @Bean
    // public KafkaAdmin kafkaAdmin() {
    //     Map<String, Object> configs = new HashMap<>();
    //     configs.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
    //     return new KafkaAdmin(configs);
    // }

    // @Bean
    // public NewTopic orderCreatedTopic() {
    //     return TopicBuilder.name("paris-order-created").build();
    // }

    // @Bean
    // public NewTopic orderItemStatusChangedTopic() {
    //     return TopicBuilder.name("paris-cancel-item-sub-order").build();
    // }

}
