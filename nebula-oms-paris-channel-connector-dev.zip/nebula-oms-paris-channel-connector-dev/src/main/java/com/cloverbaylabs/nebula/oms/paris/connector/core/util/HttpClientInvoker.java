package com.cloverbaylabs.nebula.oms.paris.connector.core.util;

import java.io.IOException;

import com.cloverbaylabs.nebula.oms.paris.connector.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.AccessToken;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.springframework.stereotype.Component;


@Slf4j
@Component
@RequiredArgsConstructor
public class HttpClientInvoker {

    private final OkHttpClient httpClient;
    private final ObjectMapper objectMapper;

    public <T> T post(String url, Headers headers, RequestBody requestPayload, Class<T> responseType) {
        return executeRequest(buildRequest(url, headers, requestPayload, HttpMethod.POST.toString()), responseType);
    }

    public <T> T get(String url, Headers headers, Class<T> responseType) {
        return executeRequest(new Request.Builder().url(url).headers(headers).get().build(), responseType);
    }

    public <T> T put(String url, Headers headers, RequestBody requestPayload, Class<T> responseType) {
        return executeRequest(buildRequest(url, headers, requestPayload, HttpMethod.PUT.toString()), responseType);
    }

    public <T> T delete(String url, Headers headers, Class<T> responseType) {
        return executeRequest(new Request.Builder().url(url).headers(headers).delete().build(), responseType);
    }

    private <T>Request buildRequest(String url,
                                    Headers headers, RequestBody requestBody,
                                    String method) {
        try {

            Request.Builder requestBuilder = new Request.Builder()
                    .url(url)
                    .method(method, requestBody);
            if (headers != null) {
                requestBuilder.headers(headers);
            }
            return requestBuilder.build();
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialize request payload", e);
        }
    }

    private <T> T executeRequest(Request request, Class<T> responseType) {
        long startTime = System.currentTimeMillis();
        logRequest(request.method(), request.headers(), request.url().toString(),
                request.body() != null ? request.body().toString() : null);
        try (Response response = httpClient.newCall(request).execute()) {
            long elapsedTime = System.currentTimeMillis() - startTime;

            String responseBody = response.body().string();

            if (!response.isSuccessful()) {
                logErrorResponse(request.method(), request.url().toString(),
                        response.code(), responseBody, elapsedTime);
                throw new RuntimeException("HTTP request failed with status code: " + response.code());
            }

            logResponse(request.method(), request.url().toString(), response.toString(), elapsedTime);
            
            return getReturnValue(responseType, responseBody);
        } catch (IOException e) {
            throw new RuntimeException("Failed to execute request", e);
        }
    }

    private <T> T getReturnValue(Class<T> responseType, String responseBody) throws JsonProcessingException {
        if (responseType == AccessToken.class) {
            String accessTokenValue = objectMapper.readTree(responseBody).get("accessToken").asText();
            AccessToken accessToken = new AccessToken();
            accessToken.setAccessToken(accessTokenValue);
            return responseType.cast(accessToken);
        }
        return objectMapper.readValue(responseBody, responseType);
    }

    private void logRequest(String method, Headers headers,
                            String url, String requestBody) {
        log.info("HTTP {} Request - Headers: {}, URL: {}, Request Body: {}",
                method, headers.toString(), url, requestBody);
    }

    private void logResponse(String method, String url, String responseBody, long elapsedTime) {
        log.info("HTTP {} Response - URL: {}, Response Body: {}, Time Taken: {} ms",
                method, url, responseBody, elapsedTime);
    }

    private void logErrorResponse(String method, String url, int statusCode,
                                  String responseBody, long elapsedTime) {
        log.error("HTTP {} Error - URL: {}, Status Code: {}, Response Body: {}, Time Taken: {} ms",
                method, url, statusCode, responseBody, elapsedTime);
    }

    public <T> T sendRequest(HttpMethod method,
                             String requestUrl, Headers headers,
                             RequestBody body, Class<T> responseType) {
        return switch (method) {
            case POST -> post(requestUrl, headers, body, responseType);
            case PUT, PATCH -> put(requestUrl, headers, body, responseType);
            case DELETE -> delete(requestUrl, headers, responseType);
            case GET -> get(requestUrl, headers, responseType);
        };

    }
}

