package com.cloverbaylabs.nebula.oms.paris.connector.core.facade.impl;

import java.util.concurrent.TimeUnit;

import com.cloverbaylabs.framework.utilities.exception.EntityNotFoundException;
import com.cloverbaylabs.nebula.oms.paris.connector.core.config.ApiAction;
import com.cloverbaylabs.nebula.oms.paris.connector.core.facade.TokenFacade;
import com.cloverbaylabs.nebula.oms.paris.connector.core.service.SecretManagerService;
import com.cloverbaylabs.nebula.oms.paris.connector.core.util.HttpClientInvoker;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.base.CachedToken;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.base.Secret;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.AccessToken;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.RequiredArgsConstructor;
import okhttp3.Headers;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TokenFacadeImpl implements TokenFacade {

    private final SecretManagerService secretManagerService;
    private final HttpClientInvoker httpClientInvoker;
    private final ApiAction apiAction;
    private static final String BEARER = "Bearer ";


    private final Cache<String, CachedToken> secretCache = Caffeine.newBuilder()
            .expireAfterWrite(12, TimeUnit.HOURS)
            .build();

    private final Cache<String, CachedToken> tokenCache = Caffeine.newBuilder()
            .expireAfterWrite(3, TimeUnit.HOURS)
            .build();

    private Secret fetchSecret(String businessGroupId, String tenantId) {

        CachedToken cachedSecret = secretCache.getIfPresent(tenantId);
        if (cachedSecret != null) {
            return new Secret(cachedSecret.getToken());
        }

        try {
            Secret secret = secretManagerService.getSecret(businessGroupId, tenantId);
            if (secret != null) {
                CachedToken newSecret = new CachedToken(secret.getApiKey());
                secretCache.put(tenantId, newSecret);
                return secret;
            }
            throw new RuntimeException("Failed to fetch access token: Empty response body");
        } catch (RuntimeException e) {
            throw new EntityNotFoundException("Shop credentials not found");
        }
    }

    @Override
    public String getAccessToken(String businessGroupId, String tenantId) {

        String apiKey = fetchSecret(businessGroupId, tenantId).getApiKey();

        CachedToken cachedToken = tokenCache.getIfPresent(apiKey);
        if (cachedToken != null) {
            return cachedToken.getToken();
        }

        Headers headers = new Headers.Builder()
                .add("Authorization", BEARER + apiKey)
                .build();
        try {
            AccessToken response = httpClientInvoker.sendRequest(
                    HttpMethod.POST,
                    apiAction.getToken(),
                    headers,
                    RequestBody.create(new byte[]{}, null),
                    AccessToken.class
            );

            if (response != null) {
                CachedToken newToken = new CachedToken(response.getAccessToken());
                tokenCache.put(apiKey, newToken);
                return response.getAccessToken();
            }
            throw new RuntimeException("Failed to fetch access token: Empty response body");
        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch access token", e);
        }
    }
}
