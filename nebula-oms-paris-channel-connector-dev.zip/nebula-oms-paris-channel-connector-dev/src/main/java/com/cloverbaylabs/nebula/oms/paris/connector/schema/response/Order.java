package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Order {
    private String id;
    private String origin;
    private String originOrderNumber;
    private String originInvoiceType;
    private String originOrderDate;
    private String createdAt;
    private Customer customer;
    private String businessInvoice;
    private Address billingAddress;
    private List<SubOrder> subOrders;
}

