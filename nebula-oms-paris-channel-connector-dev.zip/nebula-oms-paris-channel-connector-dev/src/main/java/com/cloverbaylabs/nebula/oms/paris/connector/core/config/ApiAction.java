package com.cloverbaylabs.nebula.oms.paris.connector.core.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Getter
@Component
public class ApiAction {

    @Value("${paris.marketplace.api.get-token}")
    private String token;

    @Value("${paris.marketplace.api.get-orders}")
    private String allOrders;

    @Value("${paris.marketplace.api.create-order}")
    private String createOrder;

    @Value("${paris.marketplace.api.get-product-families}")
    private String productFamilies;

    @Value("${paris.marketplace.api.get-attributes-product}")
    private String attributesByProduct;

    @Value("${paris.marketplace.api.get-attributes-variant}")
    private String attributesByVariant;

    @Value("${paris.marketplace.api.create-product}")
    private String createProduct;

    @Value("${paris.marketplace.api.update-product}")
    private String updateProduct;

    @Value("${paris.marketplace.api.book-price}")
    private String bookPrice;

    @Value("${paris.marketplace.api.create-stock}")
    private String createStock;

    @Value("${paris.marketplace.api.create-stock-with-sku-seller}")
    private String createStockWithSkuSeller;

    @Value("${paris.marketplace.api.get-all-stock}")
    private String allStock;

    @Value("${paris.marketplace.api.shipment-label}")
    private String shipmentLabel;
}
