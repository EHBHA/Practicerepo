package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AccessToken {
    private String accessToken;
}
