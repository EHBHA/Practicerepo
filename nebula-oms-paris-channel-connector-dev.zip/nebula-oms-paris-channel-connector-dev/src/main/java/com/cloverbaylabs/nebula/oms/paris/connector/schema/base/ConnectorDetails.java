package com.cloverbaylabs.nebula.oms.paris.connector.schema.base;

import com.cloverbaylabs.nebula.oms.paris.connector.schema.enums.HttpMethod;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ConnectorDetails {

    private String businessGroupId;

    private String tenantId;

    private String endpointUrl;

    private HttpMethod httpMethod;

}
