package com.cloverbaylabs.nebula.oms.paris.connector.api.config;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import static org.springframework.security.config.Customizer.withDefaults;

@EnableWebSecurity
@Configuration
public class SecurityConfig {

    @Value("${security.cors.allowed-origins}")
    private String allowedOrigins;

    @Value("${security.csp}")
    private String csp;

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    CorsConfigurationSource crossOriginConfig() {

        final CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.setAllowedOrigins(Arrays.stream(allowedOrigins.split(",")).toList());
        config.setAllowedHeaders(Collections.singletonList("*"));
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "PATCH"));
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable());
        //.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
        http.cors(cors -> cors.configurationSource(crossOriginConfig()));

        String contentSecurity = csp;
        http.headers(headers -> headers
                .contentSecurityPolicy(cs -> cs.policyDirectives(contentSecurity))
                .httpStrictTransportSecurity(hsts -> hsts
                        .requestMatcher(AnyRequestMatcher.INSTANCE)
                        .includeSubDomains(true)
                        .preload(true)
                        .maxAgeInSeconds(31536000))
                .frameOptions(HeadersConfigurer.FrameOptionsConfig::deny)
                .xssProtection(withDefaults())
                .cacheControl(withDefaults())
                .frameOptions(withDefaults())
                .contentTypeOptions(withDefaults())
                .xssProtection(withDefaults())
                .contentTypeOptions(withDefaults())
                .referrerPolicy(withDefaults())
                .permissionsPolicyHeader(pp -> pp.policy("geolocation=(self), microphone=()"))
        );

        http.authorizeHttpRequests(authorizeRequests-> authorizeRequests.anyRequest().permitAll());
        return http.build();
    }

}
