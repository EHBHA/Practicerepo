package com.cloverbaylabs.nebula.oms.paris.connector.schema.event;

import lombok.Getter;

@Getter
public enum EntityType {
    PRODUCT,
    ORDER
}
