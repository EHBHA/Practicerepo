package com.cloverbaylabs.nebula.oms.paris.connector.api.aspect;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.cloverbaylabs.lib.authgateway.dto.PermissionEvaluationRequest;
import com.cloverbaylabs.lib.authgateway.exception.TokenException;
import com.cloverbaylabs.lib.authgateway.exception.UnauthorizedException;
import com.cloverbaylabs.lib.authgateway.service.intf.PermissionEvaluationService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.CodeSignature;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


/**
 *
 */
@Component
@Aspect
@Slf4j
@AllArgsConstructor
public class LoggingAspect {

//    @Autowired
//    BillingEventService billingEventService;

    @Autowired
    PermissionEvaluationService permissionEvaluationService;

//    @Value("${external-service.auth.resource}")
//    private String authResource;

    /**
     *
     * @param joinPoint
     * @return
     * @throws Throwable
     */
    @Around("@annotation(com.cloverbaylabs.nebula.oms.paris.connector.api.aspect.TrackTime)")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
        String url = request.getRequestURL().toString();
        String method = request.getMethod();
        try {
            Map<String, String> paramNameValueMap = getParamNameValueMap(joinPoint);
//            billingEventService.sendBillingEvent(joinPoint);
//            authHelper(joinPoint, paramNameValueMap);
            Object result = joinPoint.proceed();
            logResult(joinPoint, url, method, start, result);
            return result;
        } catch (Exception e) {
            logResult(joinPoint, url, method, start, e.getMessage());
            throw e;
        }
    }

    private HashMap<String, String> getParamNameValueMap(ProceedingJoinPoint joinPoint) {
        HashMap<String, String> paramNameValueMap = new HashMap<>();
        CodeSignature codeSignature = (CodeSignature) joinPoint.getSignature();
        String[] names = codeSignature.getParameterNames();
        Object[] args = joinPoint.getArgs();
        for (int i = 0; i < names.length; i++) {
            if (Objects.nonNull(args[i])) {
                paramNameValueMap.put(names[i], args[i].toString());
            }
        }
        return paramNameValueMap;
    }

    private void logResult(ProceedingJoinPoint joinPoint, String url, String method, long start, Object result) {
        try {
            logEntry(joinPoint, url, method);
            logSuccessExit(joinPoint, url, method, start, result.toString());
        } catch (Exception e) {
            logEntry(joinPoint, url, method);
            logErrorExit(joinPoint, url, method, start, e.getMessage());
        }
    }

    private void logEntry(ProceedingJoinPoint joinPoint, String url, String method) {
        log.atInfo().setMessage("INCOMING HTTP REQUEST FOR {} {} :: Enter: {}.{}() with argument[s] = {}")
                .addArgument(method)
                .addArgument(url)
                .addArgument(joinPoint.getSignature().getDeclaringTypeName())
                .addArgument(joinPoint.getSignature().getName())
                .addArgument(joinPoint.getArgs())
                .log();
    }

    private void logErrorExit(ProceedingJoinPoint joinPoint, String url, String method, long start, String error) {
        log.atError().setMessage("ERROR HTTP RESPONSE FOR {} {} :: Exit: {}.{}() had arguments = {}, with result = {}, Execution time = {} ms")
                .addArgument(method)
                .addArgument(url)
                .addArgument(joinPoint.getSignature().getDeclaringTypeName())
                .addArgument(joinPoint.getSignature().getName())
                .addArgument(joinPoint.getArgs())
                .addArgument(error)
                .addArgument(System.currentTimeMillis() - start)
                .log();
    }

    private void logSuccessExit(ProceedingJoinPoint joinPoint, String url, String method, long start, String response) { // Fixed typo in method signature
        log.atInfo().setMessage("OUTGOING HTTP RESPONSE FOR {} {} :: Exit: {}.{}() had arguments = {}, with result = {}, Execution time = {} ms")
                .addArgument(method)
                .addArgument(url)
                .addArgument(joinPoint.getSignature().getDeclaringTypeName())
                .addArgument(joinPoint.getSignature().getName())
                .addArgument(joinPoint.getArgs()[0])
                .addArgument(response)
                .addArgument(System.currentTimeMillis() - start)
                .log();
    }

//        @SneakyThrows
    private void authHelper(ProceedingJoinPoint joinPoint, Map<String, String> paramNameValueMap) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        if (method.isAnnotationPresent(Scope.class)) {
            try {
                Scope scope = method.getAnnotation(Scope.class);
                PermissionEvaluationRequest permissionEvaluationRequest = new PermissionEvaluationRequest();
                permissionEvaluationRequest.setAudience(paramNameValueMap.get("tenantId"));

                permissionEvaluationRequest.setBusinessGroupId(paramNameValueMap.get("businessGroupId"));
                permissionEvaluationRequest.setResource("nebula-oms-ripley-connector");
                permissionEvaluationRequest.setScope(scope.value());
                permissionEvaluationRequest.setTenantId(paramNameValueMap.get("tenantId"));
                log.info("Authorizing request");
                permissionEvaluationService
                        .evaluatePermission(paramNameValueMap.get("token"), permissionEvaluationRequest);
                log.info("Authorization Successful!!!");
            } catch (UnauthorizedException e) {
                log.error("Authorization failed!!!");
                throw new UnauthorizedException(e.getErrorCode(), e.getMessage());
            } catch (TokenException e) {
                log.error("Authorization failed!!!");
                throw new TokenException(e.getErrorCode(), e.getMessage());
            } catch (Exception e) {
                log.error("Authorization failed!!!");
//                throw new SystemException(ErrorCodes.IDENTITY_INTERNAL_SERVER_ERROR.name(),
//                        e.getMessage());
            }
        }
    }
}

