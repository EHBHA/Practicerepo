package com.cloverbaylabs.nebula.oms.paris.connector.api.controller;

import com.cloverbaylabs.nebula.oms.paris.connector.api.aspect.Scope;
import com.cloverbaylabs.nebula.oms.paris.connector.api.aspect.TrackTime;
import com.cloverbaylabs.nebula.oms.paris.connector.core.service.ProductService;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.CreateProduct;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.Price;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.UpdateProduct;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.CreateProductResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.PaginatedResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ProductAttribute;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ProductDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.BUSINESS_GROUP_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.CLIENT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TENANT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TRACE_ID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/products")
@Tag(name = "Product CONTROLLER",
        description = "APIs exposed to perform product actions on paris marketplace")
public class ProductController {

    private final ProductService productService;
    private final String OFFSET = "offset";
    private final String LIMIT = "limit";
    private final String GET = "GET";

    @TrackTime
    @Operation(summary = "Get paginated families ", method = GET)
    @Scope("ne:oms:paris:products:families:get")
    @GetMapping("/v1/families")
    public ResponseEntity<PaginatedResponse<ProductDTO>> printLabel(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(name = OFFSET, required = false) Integer offset,
            @RequestParam(name = LIMIT, required = false) Integer limit) {
        return ResponseEntity
                .ok(productService.getFamilies(businessGroupId, tenantId, limit, offset));
    }

    @TrackTime
    @Operation(summary = "Get attributes by product", method = GET)
    @Scope("ne:oms:paris:products:attributes:product:get")
    @GetMapping("/v1/attributes/product/{familyId}")
    public ResponseEntity<PaginatedResponse<ProductAttribute>> getAttributesByProduct (
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(name = OFFSET, defaultValue = "0") Integer offset,
            @RequestParam(name = LIMIT, defaultValue = "10") Integer limit,
            @PathVariable("familyId") String familyId) {
        return ResponseEntity
                .ok(productService.getAttributesByProduct(businessGroupId, tenantId,
                        familyId, limit, offset));
    }

    @TrackTime
    @Operation(summary = "Get attributes by variants", method = GET)
    @Scope("ne:oms:paris:products:attributes:variants:get")
    @GetMapping("/v1/attributes/variants/{familyId}")
    public ResponseEntity<PaginatedResponse<ProductAttribute>> printgetAttributesByVarient (
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(name = OFFSET, defaultValue = "0") Integer offset,
            @RequestParam(name = LIMIT, defaultValue = "10") Integer limit,
            @PathVariable("familyId") String familyId) {
        return ResponseEntity
                .ok(productService.getAttributesByVariant(businessGroupId, tenantId,
                        familyId, limit, offset));
    }

    @TrackTime
    @Operation(summary = "Create Products", method = "POST")
    @Scope("ne:oms:paris:products:create")
    @PostMapping("/v1")
    public ResponseEntity<CreateProductResponse> createProduct(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody @Valid CreateProduct createProduct) {
        return ResponseEntity
                .ok(productService.createProduct(businessGroupId, tenantId, createProduct));
    }


    @TrackTime
    @Operation(summary = "Update Products", method = "PATCH")
    @Scope("ne:oms:paris:products:update")
    @PatchMapping("/v1/update/{id}")
    public ResponseEntity<CreateProductResponse> updateProduct(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @PathVariable String id,
            @RequestBody @Valid UpdateProduct updateProduct) {
        return ResponseEntity
                .ok(productService.updateProduct(businessGroupId, tenantId, updateProduct, id));
    }

    @TrackTime
    @Operation(summary = "Update Price Information", method = "POST")
    @Scope("ne:oms:paris:products:price:update")
    @PatchMapping("/v1/price/{sku}")
    public ResponseEntity<CreateProductResponse> updatePrice(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @PathVariable String sku,
            @RequestBody @Valid Price price) {
        return ResponseEntity
                .ok(productService.updatePrice(businessGroupId, tenantId, price, sku));
    }

    @TrackTime
    @Operation(summary = "Get all products", method = GET)
    @Scope("ne:oms:paris:products:get")
    @GetMapping("/v1/all")
    public ResponseEntity<PaginatedResponse<ProductDTO>> getAllProducts(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(name = OFFSET, defaultValue = "0", required = false) Integer offset,
            @RequestParam(name = LIMIT, defaultValue = "10", required = false) Integer limit) {
        return ResponseEntity
                .ok(productService.getAllProducts(businessGroupId, tenantId, limit, offset));
    }

    @TrackTime
    @Operation(summary = "Get categories for a specific family", method = GET)
    @Scope("ne:oms:paris:categories:get")
    @GetMapping("/v1/categories/{familyId}")
    public ResponseEntity<PaginatedResponse<ProductDTO>> getCategories(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @PathVariable("familyId") String familyId,
            @RequestParam(name = OFFSET, defaultValue = "0", required = false) Integer offset,
            @RequestParam(name = LIMIT, defaultValue = "10", required = false) Integer limit) {
        return ResponseEntity
                .ok(productService.getCategories(businessGroupId, tenantId, familyId, limit, offset));
    }
}
