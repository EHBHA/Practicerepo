package com.cloverbaylabs.nebula.oms.paris.connector.api.controller;

public class SalesController {
}
