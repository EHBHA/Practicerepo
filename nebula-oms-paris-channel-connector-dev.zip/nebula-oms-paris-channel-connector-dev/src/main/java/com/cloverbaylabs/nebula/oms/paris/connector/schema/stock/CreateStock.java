package com.cloverbaylabs.nebula.oms.paris.connector.schema.stock;

import java.util.List;

import com.cloverbaylabs.framework.utilities.constant.ValidationMessages;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CreateStock {
    @NotBlank(message = "skus List" + ValidationMessages.INVALID_MISSING)
    @Valid
    private List<Stock> skus;
}
