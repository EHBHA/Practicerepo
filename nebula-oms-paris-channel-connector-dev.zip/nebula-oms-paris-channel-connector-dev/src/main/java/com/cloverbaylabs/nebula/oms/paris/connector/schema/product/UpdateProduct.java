package com.cloverbaylabs.nebula.oms.paris.connector.schema.product;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class UpdateProduct {
    private Product product;
    private List<Variant> variants;
    private List<Price> prices;

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Product {
        private String name;
        private String sellerSku;
        private String familyId;
        private List<Attribute> attributes;
        private String category;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Attribute {
        private String id;
        private String value;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Variant {
        private String skuSeller;
        private List<Attribute> attributes;
        private List<Media> medias;
        private int quantity;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Media {
        private int position;
        private String src;
        private String name;

    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Price {
        private double value;
        private String storePrice;
        private String type;
        private String showFrom;
        private String showTo;
    }
}
