package com.cloverbaylabs.nebula.oms.paris.connector.core.service;

import java.util.List;

import com.cloverbaylabs.nebula.oms.paris.connector.schema.order.CreateOrder;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ListResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.OrderResponseList;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ShipmentLabel;

public interface OrderService {
    OrderResponseList getAllOrders(String businessGroupId, String tenantId, Integer offset, Integer limit);

    List<Integer> createOrder(String businessGroupId, String tenantId, CreateOrder createOrder);

    ListResponse<ShipmentLabel> printLabel(String businessGroupId, String tenantId, String labelId);
}
