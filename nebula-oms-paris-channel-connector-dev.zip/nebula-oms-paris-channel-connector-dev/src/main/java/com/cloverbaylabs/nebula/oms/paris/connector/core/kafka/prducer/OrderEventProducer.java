package com.cloverbaylabs.nebula.oms.paris.connector.core.kafka.prducer;

public class OrderEventProducer extends BaseEventProducer {

    // @Autowired
    // private EventTopics eventTopics;

    // public void publishOnOrderCreate(String businessGroupId,
    //                                  String tenantId,
    //                                  Object eventMsg) {
    //     var event = getEventPayload(businessGroupId,
    //             tenantId, EntityType.ORDER,
    //             EventType.ORDER_CREATE, eventMsg);
    //     publish(eventTopics.getOrderCreated(), event);
    // }

}
