package com.cloverbaylabs.nebula.oms.paris.connector.schema.base;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ErrorDTO {
    private Integer statusCode;
    private Boolean error;
    private String message;

    public ErrorDTO(Integer statusCode, Boolean error, String message) {
        this.statusCode = statusCode;
        this.error = error;
        this.message = message;
    }
}
