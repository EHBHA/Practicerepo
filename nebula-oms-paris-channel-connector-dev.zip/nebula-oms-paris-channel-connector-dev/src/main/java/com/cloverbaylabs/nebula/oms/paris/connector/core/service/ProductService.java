package com.cloverbaylabs.nebula.oms.paris.connector.core.service;

import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.CreateProduct;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.Price;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.product.UpdateProduct;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.CreateProductResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.PaginatedResponse;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ProductAttribute;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.response.ProductDTO;

public interface ProductService {
    PaginatedResponse<ProductDTO> getFamilies(String businessGroupId, String tenantId, Integer limit, Integer offset);

    PaginatedResponse<ProductAttribute> getAttributesByProduct(String businessGroupId, String tenantId, String familyId, Integer limit, Integer offset);

    PaginatedResponse<ProductAttribute> getAttributesByVariant(String businessGroupId, String tenantId, String familyId, Integer limit, Integer offset);

    CreateProductResponse createProduct(String businessGroupId, String tenantId, CreateProduct createProduct);

    CreateProductResponse updateProduct(String businessGroupId, String tenantId, UpdateProduct updateProduct, String id);

    CreateProductResponse updatePrice(String businessGroupId, String tenantId, Price price, String sku);

    PaginatedResponse<ProductDTO> getAllProducts(String businessGroupId, String tenantId, Integer limit, Integer offset);

    PaginatedResponse<ProductDTO> getCategories(String businessGroupId, String tenantId, String familyId, Integer limit, Integer offset);
}
