package com.cloverbaylabs.nebula.oms.paris.connector.core.service;

import com.cloverbaylabs.nebula.oms.paris.connector.schema.base.Secret;

public interface SecretManagerService {
    Secret getSecret(String businessGroupId, String tenantId);

}
