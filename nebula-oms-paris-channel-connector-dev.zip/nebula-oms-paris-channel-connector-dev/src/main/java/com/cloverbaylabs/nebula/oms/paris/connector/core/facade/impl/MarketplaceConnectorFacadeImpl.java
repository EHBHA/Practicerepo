package com.cloverbaylabs.nebula.oms.paris.connector.core.facade.impl;

import java.util.Map;

import com.cloverbaylabs.nebula.oms.paris.connector.core.config.ApiAction;
import com.cloverbaylabs.nebula.oms.paris.connector.core.facade.MarketplaceConnectorFacade;
import com.cloverbaylabs.nebula.oms.paris.connector.core.facade.TokenFacade;
import com.cloverbaylabs.nebula.oms.paris.connector.core.util.HttpClientInvoker;
import com.cloverbaylabs.nebula.oms.paris.connector.schema.base.ConnectorDetails;
import lombok.RequiredArgsConstructor;
import okhttp3.Headers;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MarketplaceConnectorFacadeImpl implements MarketplaceConnectorFacade {

    private final TokenFacade tokenService;
    private final HttpClientInvoker httpClientInvoker;
    private final ApiAction apiAction;

    private static final String BEARER = "Bearer ";

    @Override
    public <T> T marketplaceApiExchange(ConnectorDetails connectorDetails,
                                           RequestBody requestBody, Class<T> responseClass) {
//        Secret secret = fetchSecret(connectorDetails.getBusinessGroupId(),
//                connectorDetails.getTenantId());

        Headers headers = new Headers.Builder()
                .add("Authorization", BEARER + tokenService.getAccessToken(
                        connectorDetails.getBusinessGroupId(),
                        connectorDetails.getTenantId()
                ))
                .build();
        if (requestBody == null) {
            requestBody = RequestBody.create(new byte[]{}, null);
        }

        return httpClientInvoker.sendRequest(
                connectorDetails.getHttpMethod(),
                connectorDetails.getEndpointUrl(),
                headers,
                requestBody,
                responseClass
        );
    }


//    private String getAccessToken(Secret secret) {
//        Headers headers = new Headers.Builder()
//                .add("Authorization", BEARER + secret.getApiKey())
//                .build();
//        try {
//            AccessToken response = httpClientInvoker.sendRequest(
//                    HttpMethod.POST,
//                    apiAction.getToken(),
//                    headers,
//                    RequestBody.create(new byte[]{}, null),
//                    AccessToken.class
//            );
//
//            if (response != null) {
//                return response.getAccessToken();
//            }
//            throw new RuntimeException("Failed to fetch access token: Empty response body");
//        } catch (Exception e) {
//            throw new RuntimeException("Failed to fetch access token", e);
//        }
//    }

//    private Secret fetchSecret(String businessGroupId, String tenantId) {
//        return secretManagerService.getSecret(businessGroupId, tenantId);
//    }

    @Override
    public String buildUrlWithParams(String url, Map<String, ?> params) {
        boolean[] initialParam = {true};
        StringBuilder sb = new StringBuilder();
        sb.append(url);
        params.forEach((key, value) -> {
            if (initialParam[0]) {
                sb.append(String.format("?%s=%s", key, value));
                initialParam[0] = false;
            } else {
                sb.append(String.format("&%s=%s", key, value));
            }
        });
        return sb.toString();
    }

}
