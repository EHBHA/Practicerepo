package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ShipmentLabel {
    public String carrier;
    public String url;
    public String labels;
    public String summary;
}

