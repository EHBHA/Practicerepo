package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AdditionalAttributes {
        private int id;
        private String name;
        private String description;
}
