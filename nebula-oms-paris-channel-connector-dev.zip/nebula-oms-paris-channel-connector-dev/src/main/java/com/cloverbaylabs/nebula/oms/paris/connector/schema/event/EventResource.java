package com.cloverbaylabs.nebula.oms.paris.connector.schema.event;

public enum EventResource {
    PARIS_CONNECTOR
}
