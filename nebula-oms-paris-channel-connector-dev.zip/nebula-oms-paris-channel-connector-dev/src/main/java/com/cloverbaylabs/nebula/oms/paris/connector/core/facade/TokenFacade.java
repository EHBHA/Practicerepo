package com.cloverbaylabs.nebula.oms.paris.connector.core.facade;


public interface TokenFacade {

    String getAccessToken(String businessGroupId, String tenantId);

}
