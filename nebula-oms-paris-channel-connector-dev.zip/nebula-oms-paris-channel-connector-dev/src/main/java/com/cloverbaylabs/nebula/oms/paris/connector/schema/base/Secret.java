package com.cloverbaylabs.nebula.oms.paris.connector.schema.base;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Secret {

    private String apiKey;

    public Secret(String apiKey) {
        this.apiKey = apiKey;
    }
}
