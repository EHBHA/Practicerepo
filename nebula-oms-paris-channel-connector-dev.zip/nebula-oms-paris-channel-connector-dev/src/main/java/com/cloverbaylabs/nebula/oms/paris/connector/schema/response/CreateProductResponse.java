package com.cloverbaylabs.nebula.oms.paris.connector.schema.response;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class CreateProductResponse {
    public String id;
    public String name;
    public Family family;
    public Category category;
    public List<Channel> channels;
    public String sellerId;
    public String sellerSku;
    public String refProduct;
    public List<Attribute> attributes;
    public String status;
    public List<Variant> variants;

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Family {
        public String id;
        public String name;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Category {
        public String id;
        public String src;
        public String name;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Channel {
        public String id;
        public String url;
        public String name;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Attribute {
        public String id;
        public String name;
        public String value;
        public String optionName;
        public String optionId;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Variant {
        public String id;
        public String sku;
        public String skuSeller;
        public List<Media> medias;
        public List<Price> prices;
        public List<Attribute> attributes;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Media {
        public int position;
        public String src;
    }

    @NoArgsConstructor
    @Getter
    @Setter
    public static class Price {
        public String id;
        public double value;
        public PriceType type;
    }
    @NoArgsConstructor
    @Getter
    @Setter
    public static class PriceType {
        public String id;
        public String name;
    }
}
