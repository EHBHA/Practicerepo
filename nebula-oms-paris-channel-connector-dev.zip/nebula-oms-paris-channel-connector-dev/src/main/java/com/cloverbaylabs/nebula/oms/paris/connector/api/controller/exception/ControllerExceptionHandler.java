package com.cloverbaylabs.nebula.oms.paris.connector.api.controller.exception;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.cloverbaylabs.framework.utilities.constant.ValidationMessages;
import com.cloverbaylabs.framework.utilities.dto.error.ErrorDto;
import com.cloverbaylabs.framework.utilities.dto.error.ErrorResponse;
import com.cloverbaylabs.lib.authgateway.exception.TokenException;
import com.cloverbaylabs.lib.authgateway.exception.UnauthorizedException;
import com.cloverbaylabs.nebula.oms.paris.connector.core.constants.ErrorCodes;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@ControllerAdvice
@Slf4j
public class ControllerExceptionHandler {

    /**
     * @method handleValidationExceptions
     * @param exception exception
     * @description Handles a MethodArgumentNotValidException
     * @return ErrorResponse
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public final ResponseEntity<ErrorResponse> handleValidationExceptions(
            MethodArgumentNotValidException exception) {
        log.error("VALIDATION ERROR::: ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        List<ErrorDto> errors = errorResponse.getErrors();

        exception.getBindingResult().getFieldErrors()
                .forEach(error -> errors.add(new ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_VALIDATION_ERROR.name(),
                        error.getField(), error.getDefaultMessage())));

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errorResponse);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleException(Exception e) {
        List<ErrorDto> errors = new ArrayList<>();
        log.error("UNHANDLED EXCEPTION :: ", e);
        errors.add(
                new ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_SERVER_ERROR.name(),
                        null, "Oops! Something went wrong"));
        ErrorResponse errorResponse = new ErrorResponse(errors);
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(errorResponse);
    }


    /**
     * @method handleMissingRequestHeader
     * @param exception exception
     * @description Handles a MissingRequestHeaderException
     * @return ErrorResponse
     */
    @ExceptionHandler(MissingRequestHeaderException.class)
    public final ResponseEntity<ErrorResponse> handleMissingRequestHeader
    (MissingRequestHeaderException exception) {
        log.error("MISSING MANDATORY HEADER:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_VALIDATION_ERROR.name(),
                exception.getHeaderName(), ValidationMessages.HEADER_MISSING));

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errorResponse);
    }

        /**
     * @method handleInvalidRequestDataType
     * @param exception exception
     * @return ErrorResponse
     * @description Exception handler for handleInvalidRequestDataType Exception
     */
    @ExceptionHandler(JsonProcessingException.class)
    public final ResponseEntity<ErrorResponse> handleInvalidRequestDataType(JsonProcessingException exception) {
        log.error("JSON PROCESSING EXCEPTION::::", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(
                new ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_BAD_REQUEST.name(),
                        "Error processing response from the server"));

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errorResponse);
    }

    /**
     *
     */
    @ExceptionHandler(TokenException.class)
    public ResponseEntity<ErrorResponse> handleTokenException(TokenException e) {
        log.error("TOKEN EXCEPTION:::", e);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new ErrorDto(e.getErrorCode().name(),
                e.getMessage()));
        return ResponseEntity
                .status(e.getErrorCode().getHttpStatus())
                .body(errorResponse);
    }

    /**
     *
     * @param e
     * @return
     */
    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<ErrorResponse> handleUnAuthorizedException(UnauthorizedException e) {
        log.error("UNAUTHORIZED EXCEPTION:::", e);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new ErrorDto(e.getErrorCode().name(),
                e.getMessage()));
        return ResponseEntity
                .status(e.getErrorCode().getHttpStatus())
                .body(errorResponse);
    }

    /**
     * @method handleHttpMediaTypeNotAcceptableException
     * @param e exception
     * @return ErrorResponse
     * @description Exception handler for handleHttpMediaTypeNotAcceptableException
     */
    @ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
    public ResponseEntity<ErrorResponse>
    handleHttpMediaTypeNotAcceptableException(HttpMediaTypeNotAcceptableException e) {
        log.error("UN-ACCEPTABLE MEDIA TYPE:::", e);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new ErrorDto(
                ErrorCodes.NEBULA_OMS_PARIS_MEDIA_TYPE_NOT_SUPPORTED.name(),
                ValidationMessages.MEDIA_TYPE_NOT_SUPPORTED));
        return ResponseEntity
                .status(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
                .body(errorResponse);
    }

    /**
     * @method handleHttpMediaTypeNotSupportedException
     * @param e exception
     * @return ErrorResponse
     * @description Exception handler for handleHttpMediaTypeNotSupportedException
     */
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ErrorResponse>
    handleHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException e) {
        log.error("UNSUPPORTED MEDIA TYPE EXCEPTION:::", e);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new ErrorDto(ErrorCodes
                .NEBULA_OMS_PARIS_MEDIA_TYPE_NOT_SUPPORTED.name(),
                ValidationMessages.MEDIA_TYPE_NOT_SUPPORTED));
        return ResponseEntity
                .status(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
                .body(errorResponse);
    }

    /**
     * @method handlerHttpRequestMethodNotSupportedException
     * @param e exception
     * @return ErrorResponse
     * @description Exception handler for handlerHttpRequestMethodNotSupportedException
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErrorResponse>
    handlerHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e) {
        log.error("METHOD NOT SUPPORTED EXCEPTION:::", e);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new ErrorDto(
                ErrorCodes.NEBULA_OMS_PARIS_METHOD_NOT_ALLOWED.name(),
                e.getMethod(),
                ValidationMessages.METHOD_NOT_ALLOWED));
        return ResponseEntity
                .status(HttpStatus.METHOD_NOT_ALLOWED)
                .body(errorResponse);
    }

    /**
     * @method handleInvalidRequestDataType
     * @param e exception
     * @return ErrorResponse
     * @description Exception handler for HttpMessageNotReadableException
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public final ResponseEntity<ErrorResponse>
    handleInvalidRequestDataType(HttpMessageNotReadableException e) {
        log.error("MALFORMED REQUEST::::", e);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(
                new ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_VALIDATION_ERROR.name(),
                        ValidationMessages.MALFORMED_REQUEST));
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errorResponse);
    }

    /**
     * @method handleMissingRequestParam
     * @param exception exception
     * @return ErrorResponse
     * @description Exception handler for a Servlet Request Exception
     */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public final ResponseEntity<ErrorResponse>
    handleMissingRequestParam(MissingServletRequestParameterException exception) {
        log.error("MISSING MANDATORY PARAMS:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new ErrorDto(
                ErrorCodes.NEBULA_OMS_PARIS_VALIDATION_ERROR.name(),
                exception.getParameterName(), ValidationMessages.MANDATORY_PARAM_MISSING));

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errorResponse);
    }

    /**
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public final ResponseEntity<ErrorResponse>
    handleIllegalArgumentException(IllegalArgumentException exception) {
        log.error("ILLEGAL ARGUMENT EXCEPTION:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();

        errorResponse.getErrors().add(new
                ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_VALIDATION_ERROR.name(),
                exception.getMessage()));
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errorResponse);
    }

    /**
     *
     * @param exception
     * @return
     */
//     @ExceptionHandler(RipleyApiException.class)
//     public final ResponseEntity<ErrorResponse>
//     handleRipleyApiException(RipleyApiException exception) {
//         log.error("RIPLEY API EXCEPTION:::  ", exception);
//         ErrorResponse errorResponse = new ErrorResponse();

//         errorResponse.getErrors().add(new
//                 ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_BAD_REQUEST.name(),
//                 exception.getRipleyError().getMessage()));
//         return ResponseEntity
//                 .status(HttpStatus.BAD_REQUEST)
//                 .body(errorResponse);
//     }

    /**
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(NoResourceFoundException.class)
    public final ResponseEntity<ErrorResponse>
    handleNoResourceFoundException(NoResourceFoundException exception) {
        log.error("NO RESOURCE FOUND EXCEPTION:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();

        errorResponse.getErrors().add(new
                ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_NOT_FOUND.name(),
                "Requested resource not found"));
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errorResponse);
    }

    /**
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(IOException.class)
    public final ResponseEntity<ErrorResponse>
    handleIOException(IOException exception) {
        log.error("IO EXCEPTION:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new
                ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_VALIDATION_ERROR.name(),
                exception.getMessage()));
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(errorResponse);
    }

    /**
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(HttpServerErrorException.InternalServerError.class)
    public final ResponseEntity<ErrorResponse>
    handleInternalServerErrorException(
            HttpServerErrorException.InternalServerError exception) {
        log.error("INTERNAL SERVER ERROR EXCEPTION:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new
                ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_SERVER_ERROR.name(),
                ValidationMessages.INTERNAL_SERVER_ERROR));
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(errorResponse);
    }

    /**
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(HttpServerErrorException.ServiceUnavailable.class)
    public final ResponseEntity<ErrorResponse>
    handleServiceUnavailableException(
            HttpServerErrorException.ServiceUnavailable exception) {
        log.error("SERVICE UNAVAILABLE EXCEPTION:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new
                ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_SERVICE_UN_AVAILABLE.name(),
                "Service temporarily unavailable. Please try again later"));
        return ResponseEntity
                .status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(errorResponse);
    }

    /**
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(HttpServerErrorException.BadGateway.class)
    public final ResponseEntity<ErrorResponse>
    handleBadGatewayException(
            HttpServerErrorException.BadGateway exception) {
        log.error("BAD GATEWAY EXCEPTION:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new
                ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_BAD_GATEWAY.name(),
                "Service temporarily unavailable. Please try again later"));
        return ResponseEntity
                .status(HttpStatus.BAD_GATEWAY)
                .body(errorResponse);
    }

    /**
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(HttpServerErrorException.GatewayTimeout.class)
    public final ResponseEntity<ErrorResponse>
    handleGatewayTimeoutException(
            HttpServerErrorException.GatewayTimeout exception) {
        log.error("GATEWAY TIMEOUT EXCEPTION:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new
                ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_SERVICE_GATEWAY_TIMEOUT.name(),
                "The server did not respond in time. Please try again"));
        return ResponseEntity
                .status(HttpStatus.GATEWAY_TIMEOUT)
                .body(errorResponse);
    }

    /**
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(RuntimeException.class)
    public final ResponseEntity<ErrorResponse>
    handleRuntimeException(
            RuntimeException exception) {
        log.error("RUNTIME EXCEPTION:::  ", exception);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.getErrors().add(new
                ErrorDto(ErrorCodes.NEBULA_OMS_PARIS_SERVER_ERROR.name(),
                exception.getMessage()));
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(errorResponse);
    }

}
