package com.cloverbaylabs.nebula.oms.paris.connector.schema.enums;

import lombok.Getter;

@Getter
public enum HttpMethod {
    POST,
    PUT,
    PATCH,
    DELETE,
    GET
}
