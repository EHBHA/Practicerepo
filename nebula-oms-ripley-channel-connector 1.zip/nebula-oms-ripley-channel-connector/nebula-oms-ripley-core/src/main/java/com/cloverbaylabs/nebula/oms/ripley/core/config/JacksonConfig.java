package com.cloverbaylabs.nebula.oms.ripley.core.config;

import java.io.IOException;
import java.util.Set;

import com.cloverbaylabs.nebula.oms.ripley.core.exception.CustomJsonFormatException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;
import static com.fasterxml.jackson.databind.DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT;
import static com.fasterxml.jackson.databind.DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY;
import static com.fasterxml.jackson.databind.DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE;
import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static com.fasterxml.jackson.databind.DeserializationFeature.READ_ENUMS_USING_TO_STRING;
import static com.fasterxml.jackson.databind.DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL;
import static com.fasterxml.jackson.databind.MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES;
import static com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS;
import static com.fasterxml.jackson.databind.SerializationFeature.WRITE_ENUMS_USING_TO_STRING;
import static java.util.Objects.requireNonNullElse;

@Slf4j
@Configuration(proxyBeanMethods = true)
public class JacksonConfig {

    public static final String FAIL_SAFE_OBJECT_MAPPER_BEAN = "fail-safe-object-mapper";

    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        return new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .registerModule(new CustomBooleanModule())
                .setSerializationInclusion(NON_NULL)
                .disable(ADJUST_DATES_TO_CONTEXT_TIME_ZONE)
                .disable(WRITE_DATES_AS_TIMESTAMPS)
                .enable(READ_ENUMS_USING_TO_STRING)
                .enable(WRITE_ENUMS_USING_TO_STRING)
                .enable(FAIL_ON_UNKNOWN_PROPERTIES)
                .setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }

    @Bean(FAIL_SAFE_OBJECT_MAPPER_BEAN)
    public ObjectMapper safeObjectMapper() {
        return JsonMapper.builder()
                .configure(ACCEPT_CASE_INSENSITIVE_PROPERTIES, true)
                .disable(ADJUST_DATES_TO_CONTEXT_TIME_ZONE)
                .disable(WRITE_DATES_AS_TIMESTAMPS)
                .disable(FAIL_ON_UNKNOWN_PROPERTIES)
                .enable(READ_ENUMS_USING_TO_STRING)
                .enable(WRITE_ENUMS_USING_TO_STRING)
                .enable(READ_UNKNOWN_ENUM_VALUES_AS_NULL)
                .configure(ACCEPT_SINGLE_VALUE_AS_ARRAY, true)
                .configure(ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
                .build()
                .registerModule(new JavaTimeModule())
                .setSerializationInclusion(NON_NULL)
                .setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }

}

class CustomBooleanModule extends SimpleModule {
    public CustomBooleanModule() {
        addDeserializer(Boolean.class, new CustomBooleanDeserializer());
    }

    private static class CustomBooleanDeserializer extends JsonDeserializer<Boolean> {
        @Override
        public Boolean deserialize(JsonParser p, DeserializationContext ctx) throws IOException {
            var token = requireNonNullElse(p.getValueAsString(), "");
            if (Set.of("true", "false", "TRUE", "FALSE").contains(token)) {
                return Boolean.parseBoolean(token.toLowerCase());
            }
            throw CustomJsonFormatException.from(p, "Value should be either 'true' or 'false' or 'TRUE' or 'FALSE'",
                    token, Boolean.class);
        }
    }
}
