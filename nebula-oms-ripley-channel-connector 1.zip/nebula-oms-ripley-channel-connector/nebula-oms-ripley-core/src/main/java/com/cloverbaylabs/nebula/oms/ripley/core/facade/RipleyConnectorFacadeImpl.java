package com.cloverbaylabs.nebula.oms.ripley.core.facade;

import com.cloverbaylabs.nebula.oms.ripley.core.facade.intf.RipleyConnectorFacade;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.SecretManagerService;
import com.cloverbaylabs.nebula.oms.ripley.core.util.HttpClientInvoker;
import com.cloverbaylabs.nebula.oms.ripley.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.ripley.schema.base.Secret;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class RipleyConnectorFacadeImpl implements RipleyConnectorFacade {

    private final HttpClientInvoker httpClientInvoker;

    private final SecretManagerService secretManagerService;

    @Override
    public <T> T executeRipleyApiRequest(ConnectorDetails connectorDetails,
                                         RequestBody requestBody,
                                         Class<T> responseClass) {

        Secret secret = fetchSecret(connectorDetails.getBusinessGroupId(),
                connectorDetails.getTenantId());

        Headers headers = new Headers.Builder()
                .add("Authorization", secret.getApiKey())
                .build();
        if (requestBody == null) {
            requestBody = RequestBody.create(new byte[]{}, null);
        }
        return httpClientInvoker.sendRequest(connectorDetails.getHttpMethod(),
                connectorDetails.getEndpointUrl(),
                headers,
                requestBody,
                responseClass);
    }

    /**
     * Fetches the secret for the given business group and tenant.
     */
    private Secret fetchSecret(String businessGroupId, String tenantId) {
        return secretManagerService.getSecret(businessGroupId, tenantId);
    }

}
