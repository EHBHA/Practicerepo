package com.cloverbaylabs.nebula.oms.ripley.core.service.intf;

import com.cloverbaylabs.nebula.oms.ripley.schema.base.Secret;

public interface SecretManagerService {

    Secret getSecret(String businessGroupId, String tenantId);
}
