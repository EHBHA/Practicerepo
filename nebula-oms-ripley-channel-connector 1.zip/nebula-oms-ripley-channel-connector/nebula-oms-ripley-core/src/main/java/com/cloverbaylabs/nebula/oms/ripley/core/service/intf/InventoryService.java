package com.cloverbaylabs.nebula.oms.ripley.core.service.intf;

import com.cloverbaylabs.nebula.oms.ripley.schema.dto.OfferUpdateDto;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ImportResponse;

public interface InventoryService {

    ImportResponse syncInventory(String businessGroupId,
                                 String tenantId,
                                 OfferUpdateDto offerUpdateDto);
}
