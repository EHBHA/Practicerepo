package com.cloverbaylabs.nebula.oms.ripley.core.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import static com.cloverbaylabs.nebula.oms.ripley.core.config.JacksonConfig.FAIL_SAFE_OBJECT_MAPPER_BEAN;

@Component
public class JsonConvertor {

    private final ObjectMapper objectMapper;


    public JsonConvertor(@Qualifier(FAIL_SAFE_OBJECT_MAPPER_BEAN)
                         ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @SneakyThrows
    public <T> String convertToString(T object) {
        return objectMapper.writeValueAsString(object);
    }

    @SneakyThrows
    public <T> T convertToObject(String json, Class<T> responseType) {
        return objectMapper.readValue(json, responseType);
    }

    @SneakyThrows
    public <T> T readValue(String json,
                          TypeReference<T> typeReference) {
        return objectMapper.readValue(json, typeReference);
    }
}
