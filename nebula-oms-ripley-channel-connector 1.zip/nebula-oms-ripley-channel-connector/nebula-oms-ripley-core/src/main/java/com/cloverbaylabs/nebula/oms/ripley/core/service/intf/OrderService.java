package com.cloverbaylabs.nebula.oms.ripley.core.service.intf;

import java.time.LocalDateTime;

import com.cloverbaylabs.nebula.oms.ripley.schema.response.Orders;

public interface OrderService {

    Orders getOrders(String businessGroupId,
                     String tenantId,
                     LocalDateTime startUpdateDate,
                     LocalDateTime endUpdateDate,
                     boolean paginate,
                     int offset,
                     int limit);
}
