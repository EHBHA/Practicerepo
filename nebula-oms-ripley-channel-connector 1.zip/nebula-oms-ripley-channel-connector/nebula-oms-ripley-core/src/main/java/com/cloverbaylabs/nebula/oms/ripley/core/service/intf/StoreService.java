package com.cloverbaylabs.nebula.oms.ripley.core.service.intf;

import com.cloverbaylabs.nebula.oms.ripley.schema.response.StoreInformation;

public interface StoreService {

    StoreInformation getStoreInformation(String businessGroupId,
                                         String tenantId);
}
