package com.cloverbaylabs.nebula.oms.ripley.core.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.cloverbaylabs.nebula.oms.ripley.core.config.ConnectionEndpoints;
import com.cloverbaylabs.nebula.oms.ripley.core.facade.intf.RipleyConnectorFacade;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.OrderService;
import com.cloverbaylabs.nebula.oms.ripley.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.ripley.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.Orders;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import static com.cloverbaylabs.nebula.oms.ripley.core.util.UrlUtil.buildUrl;

@Slf4j
@Service
@RequestMapping("api/orders")
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final ConnectionEndpoints connections;

    private final RipleyConnectorFacade ripleyConnectorFacade;

    @Override
    @SneakyThrows
    public Orders getOrders(String businessGroupId,
                            String tenantId,
                            LocalDateTime startUpdateDate,
                            LocalDateTime endUpdateDate,
                            boolean paginate,
                            int offset,
                            int limit) {

        Map<String, Object> params = new HashMap<>();
        params.put("start_update_date", startUpdateDate);
        params.put("end_update_date", endUpdateDate);
        params.put("paginate", paginate);
        params.put("offset", offset);
        params.put("max", limit);

        String url = buildUrl(connections.getStoreDeals(),
                params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, Orders.class);
    }
}
