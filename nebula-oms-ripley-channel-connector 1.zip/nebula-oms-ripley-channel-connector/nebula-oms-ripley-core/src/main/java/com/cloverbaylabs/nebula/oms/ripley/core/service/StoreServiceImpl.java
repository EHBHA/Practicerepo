package com.cloverbaylabs.nebula.oms.ripley.core.service;

import com.cloverbaylabs.nebula.oms.ripley.core.config.ConnectionEndpoints;
import com.cloverbaylabs.nebula.oms.ripley.core.facade.intf.RipleyConnectorFacade;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.StoreService;
import com.cloverbaylabs.nebula.oms.ripley.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.ripley.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.StoreInformation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class StoreServiceImpl implements StoreService {

    private final ConnectionEndpoints connections;

    private final RipleyConnectorFacade ripleyConnectorFacade;

    @Override
    public StoreInformation getStoreInformation(String businessGroupId,
                                                String tenantId) {
        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(connections.getStoreInformation()).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, StoreInformation.class);
    }
}
