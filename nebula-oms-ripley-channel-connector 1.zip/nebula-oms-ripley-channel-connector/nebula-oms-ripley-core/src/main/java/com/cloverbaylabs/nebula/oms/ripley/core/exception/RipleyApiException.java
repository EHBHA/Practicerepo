package com.cloverbaylabs.nebula.oms.ripley.core.exception;

import com.cloverbaylabs.nebula.oms.ripley.schema.base.RipleyError;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.stereotype.Component;

@EqualsAndHashCode(callSuper = true)
@Data
@Component
public class RipleyApiException extends RuntimeException {
    private RipleyError ripleyError;

    public RipleyApiException() {
    }

    public RipleyApiException(RipleyError ripleyError) {
        this.ripleyError = ripleyError;
    }
}
