package com.cloverbaylabs.nebula.oms.ripley.core.service.intf;

import java.util.List;

import com.cloverbaylabs.nebula.oms.ripley.schema.response.AttributeValues;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ImportResponse;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.OfferErrorStatus;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductAttributes;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductErrorStatus;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductHierarchy;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductOffers;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.StoreDeals;
import org.springframework.web.multipart.MultipartFile;

public interface ProductService {

    ImportResponse importProducts(String businessGroupId,
                                  String tenantId, MultipartFile multipartFile);

    OfferErrorStatus getOfferErrorStatus(String businessGroupId,
                                         String tenantId, String importId);

    ProductErrorStatus getProductErrorStatus(String businessGroupId,
                                             String tenantId,
                                             String importId);

    ProductHierarchy getHierarchies(String businessGroupId,
                                    String tenantId);

    ProductAttributes getProductAttributes(String businessGroupId,
                                           String tenantId);

    AttributeValues getAttributeValues(String businessGroupId,
                                       String tenantId);

    ProductOffers getProductOffers(String businessGroupId,
                                   String tenantId,
                                   List<String> productIds);

    StoreDeals getStoreDeals(String businessGroupId,
                             String tenantId,
                             String sku,
                             boolean paginate,
                             int offset,
                             int limit);



}
