package com.cloverbaylabs.nebula.oms.ripley.core.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cloverbaylabs.nebula.oms.ripley.core.config.ConnectionEndpoints;
import com.cloverbaylabs.nebula.oms.ripley.core.facade.intf.RipleyConnectorFacade;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.ProductService;
import com.cloverbaylabs.nebula.oms.ripley.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.ripley.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.AttributeValues;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ImportResponse;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.OfferErrorStatus;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductAttributes;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductErrorStatus;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductHierarchy;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductOffers;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.StoreDeals;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import static com.cloverbaylabs.nebula.oms.ripley.core.util.UrlUtil.buildUrl;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ConnectionEndpoints connections;

    private final RipleyConnectorFacade ripleyConnectorFacade;

    private static final String FORM_DATA = "multipart/form-data";

    private final MediaType mediaType = MediaType.parse(FORM_DATA);

    @Override
    public ImportResponse importProducts(String businessGroupId, String tenantId,
                                         MultipartFile multipartFile) {
        try {
            RequestBody requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("file", multipartFile.getName(),
                            RequestBody.create(multipartFile.getBytes(), MediaType.parse("text/csv")))
                    .addFormDataPart("import_mode", "NORMAL")
                    .addFormDataPart("with_products", "true")
                    .build();

            ConnectorDetails connectorDetails = ConnectorDetails.builder()
                    .businessGroupId(businessGroupId)
                    .tenantId(tenantId)
                    .httpMethod(HttpMethod.POST)
                    .endpointUrl(connections.getImportProducts()).build();

            return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                    requestBody, ImportResponse.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public OfferErrorStatus getOfferErrorStatus(String businessGroupId,
                                                String tenantId,
                                                String importId) {

        String url = connections.getImportOfferStatus()
                .replace("{import_id}", importId);
        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, OfferErrorStatus.class);
    }

    @Override
    public ProductErrorStatus getProductErrorStatus(String businessGroupId,
                                                    String tenantId,
                                                    String importId) {

        String url = connections.getImportProductStatus()
                .replace("{import_id}", importId);
        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, ProductErrorStatus.class);
    }

    @Override
    public ProductHierarchy getHierarchies(String businessGroupId,
                                           String tenantId) {
        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(connections.getProductHierarchies()).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, ProductHierarchy.class);
    }

    @Override
    public ProductAttributes getProductAttributes(String businessGroupId,
                                                  String tenantId) {
        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(connections.getProductAttributes()).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, ProductAttributes.class);
    }

    @Override
    public AttributeValues getAttributeValues(String businessGroupId,
                                              String tenantId) {
        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(connections.getAttributeValues()).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, AttributeValues.class);
    }

    @Override
    @SneakyThrows
    public ProductOffers getProductOffers(String businessGroupId,
                                          String tenantId,
                                          List<String> productIds) {
        Map<String, Object> params = new HashMap<>();
        params.put("product_ids", productIds);

        String url = buildUrl(connections.getProductOffers(),
                params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, ProductOffers.class);
    }

    @Override
    @SneakyThrows
    public StoreDeals getStoreDeals(String businessGroupId,
                                    String tenantId,
                                    String sku,
                                    boolean paginate,
                                    int offset,
                                    int limit) {

        Map<String, Object> params = new HashMap<>();
        params.put("sku", sku);
        params.put("paginate", paginate);
        params.put("offset", offset);
        params.put("max", limit);

        String url = buildUrl(connections.getStoreDeals(),
                params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url).build();

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                null, StoreDeals.class);
    }
}
