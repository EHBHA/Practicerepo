package com.cloverbaylabs.nebula.oms.ripley.core.service;

import com.cloverbaylabs.framework.utilities.exception.EntityNotFoundException;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.SecretManagerService;
import com.cloverbaylabs.nebula.oms.ripley.schema.base.Secret;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueResponse;
import software.amazon.awssdk.services.secretsmanager.model.ResourceNotFoundException;

@Service
@RequiredArgsConstructor
public class SecretManagerServiceImpl implements SecretManagerService {

    private final SecretsManagerClient secretsManagerClient;

    private final ObjectMapper objectMapper;

    @Value("${aws.secret.format}")
    private String secretFormat;

    @Override
    @SneakyThrows
    public Secret getSecret(String businessGroupId, String tenantId) {

        String formattedSecretId = secretFormat
                .replace("{businessGroupId}", businessGroupId)
                .replace("{tenantId}", tenantId);
        GetSecretValueRequest getSecretValueRequest = GetSecretValueRequest.builder()
                .secretId(formattedSecretId)
                .build();
        try {
            GetSecretValueResponse getSecretValueResponse =
                    secretsManagerClient.getSecretValue(getSecretValueRequest);
            return objectMapper.readValue(getSecretValueResponse.secretString(),
                    Secret.class);

        } catch (ResourceNotFoundException e) {
            throw new EntityNotFoundException("Shop credentials not found");
        }

    }
}
