package com.cloverbaylabs.nebula.oms.ripley.core.service;

import com.cloverbaylabs.nebula.oms.ripley.core.config.ConnectionEndpoints;
import com.cloverbaylabs.nebula.oms.ripley.core.facade.intf.RipleyConnectorFacade;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.InventoryService;
import com.cloverbaylabs.nebula.oms.ripley.core.util.JsonConvertor;
import com.cloverbaylabs.nebula.oms.ripley.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.ripley.schema.dto.OfferUpdateDto;
import com.cloverbaylabs.nebula.oms.ripley.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ImportResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class InventoryServiceImpl implements InventoryService {

    private final ConnectionEndpoints connections;

    private final RipleyConnectorFacade ripleyConnectorFacade;

    private final JsonConvertor jsonConvertor;

    private static final String APPLICATION_JSON = "application/json";

    private final MediaType mediaType = MediaType.parse(APPLICATION_JSON);

    @Override
    public ImportResponse syncInventory(String businessGroupId,
                                        String tenantId,
                                        OfferUpdateDto offerUpdateDto) {
        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.POST)
                .endpointUrl(connections.getUpdateOffers()).build();
        String jsonPayload = jsonConvertor.convertToString(offerUpdateDto);

        RequestBody requestBody = RequestBody.create(jsonPayload,
                mediaType);

        return ripleyConnectorFacade.executeRipleyApiRequest(connectorDetails,
                requestBody, ImportResponse.class);
    }
}
