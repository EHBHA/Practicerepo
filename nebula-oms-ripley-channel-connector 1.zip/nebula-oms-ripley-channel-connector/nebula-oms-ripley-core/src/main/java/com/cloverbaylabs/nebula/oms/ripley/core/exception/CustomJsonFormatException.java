package com.cloverbaylabs.nebula.oms.ripley.core.exception;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;

public class CustomJsonFormatException extends InvalidFormatException {
    private CustomJsonFormatException(JsonParser p, String msg, Object value, Class<?> targetType) {
        super(p, msg, value, targetType);
    }

    public static CustomJsonFormatException from(JsonParser p, String msg, Object value, Class<?> targetType) {
        return new CustomJsonFormatException(p, msg, value, targetType);
    }
}
