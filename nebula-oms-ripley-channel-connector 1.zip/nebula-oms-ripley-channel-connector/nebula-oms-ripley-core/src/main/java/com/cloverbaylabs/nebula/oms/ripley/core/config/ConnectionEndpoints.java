package com.cloverbaylabs.nebula.oms.ripley.core.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 *  Ripley Api Actions
 */
@Getter
@Component
public class ConnectionEndpoints {

    @Value("${ripley.url.products.import-products}")
    private String importProducts;

    @Value("${ripley.url.products.import-offers-status}")
    private String importOfferStatus;

    @Value("${ripley.url.products.import-offers-error-report}")
    private String importOfferErrorReport;

    @Value("${ripley.url.products.import-products-status}")
    private String importProductStatus;

    @Value("${ripley.url.products.import-products-error-report}")
    private String importProductErrorReport;

    @Value("${ripley.url.products.product-hierarchies}")
    private String productHierarchies;

    @Value("${ripley.url.products.product-attributes}")
    private String productAttributes;

    @Value("${ripley.url.products.attribute-values}")
    private String attributeValues;

    @Value("${ripley.url.products.store-deals}")
    private String storeDeals;

    @Value("${ripley.url.products.product-offers}")
    private String productOffers;

    @Value("${ripley.url.products.store-information}")
    private String storeInformation;

    @Value("${ripley.url.products.update-offers}")
    private String updateOffers;

}
