package com.cloverbaylabs.nebula.oms.ripley.core.facade.intf;

import com.cloverbaylabs.nebula.oms.ripley.schema.base.ConnectorDetails;
import okhttp3.RequestBody;

public interface RipleyConnectorFacade {

    <T> T executeRipleyApiRequest(ConnectorDetails connectorDetails,
                                  RequestBody requestBody,
                                  Class<T> responseClass);
}
