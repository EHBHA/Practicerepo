package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import java.util.List;
import lombok.Data;

@Data
public class StoreDeals{
    private List<OffersItem> offers;
    private int totalCount;

    @Data
    public static class OffersItem{
        private boolean allowQuoteRequests;
        private String categoryLabel;
        private int quantity;
        private String shopSku;
        private int totalPrice;
        private String categoryCode;
        private int minShippingPriceAdditional;
        private List<Object> productReferences;
        private boolean active;
        private Object description;
        private Object discount;
        private int offerId;
        private String productTitle;
        private String productSku;
        private Object priceAdditionalInfo;
        private String minShippingZone;
        private List<String> channels;
        private String currencyIsoCode;
        private int price;
        private LogisticClass logisticClass;
        private int minShippingPrice;
        private List<Object> offerAdditionalFields;
        private String stateCode;
        private String minShippingType;

        @Data
        public static class LogisticClass{
            private String code;
            private String label;
        }
    }
}