package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import lombok.Data;

@Data
public class ProductErrorStatus{
    private boolean hasTransformedFile;
    private String dateCreated;
    private boolean hasNewProductReport;
    private boolean hasErrorReport;
    private int importId;
    private String importStatus;
    private int transformLinesRead;
    private int transformLinesWithWarning;
    private int transformLinesInSuccess;
    private boolean hasTransformationErrorReport;
    private int transformLinesInError;
}