package com.cloverbaylabs.nebula.oms.ripley.schema.enums;

import lombok.Getter;

@Getter
public enum HttpMethod {

    POST,
    PUT,
    PATCH,
    DELETE,
    GET
}
