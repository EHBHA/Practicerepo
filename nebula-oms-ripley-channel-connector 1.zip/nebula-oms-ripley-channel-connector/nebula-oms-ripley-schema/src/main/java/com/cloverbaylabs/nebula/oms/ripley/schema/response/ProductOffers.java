package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import java.util.List;
import lombok.Data;

@Data
public class ProductOffers{
    private List<ProductsItem> products;

    @Data
    public static class ProductsItem{
        private List<Object> offers;
        private String productSku;
        private String categoryLabel;
        private String categoryCode;
        private int totalCount;
        private List<Object> productReferences;
        private String productTitle;
    }
}