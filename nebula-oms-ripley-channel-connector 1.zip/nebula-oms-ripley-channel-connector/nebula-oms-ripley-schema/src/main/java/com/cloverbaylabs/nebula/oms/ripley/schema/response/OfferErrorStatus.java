package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import lombok.Data;

@Data
public class OfferErrorStatus {
    private int linesInPending;
    private int linesInError;
    private String dateCreated;
    private boolean hasErrorReport;
    private int importId;
    private int linesRead;
    private String type;
    private String mode;
    private int offerDeleted;
    private int linesInSuccess;
    private int offerUpdated;
    private int offerInserted;
    private String status;
}