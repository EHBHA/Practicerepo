package com.cloverbaylabs.nebula.oms.ripley.schema.dto;

import java.util.List;
import lombok.Data;

@Data
public class OfferUpdateDto{
	private List<OffersItem> offers;

	@Data
	public static class OffersItem{
		private Object availableEnded;
		private String updateDelete;
		private int quantity;
		private String shopSku;
		private Object availableStarted;
		private int price;
		private String productId;
		private String productIdType;
		private String stateCode;
		private Object minQuantityAlert;
	}
}