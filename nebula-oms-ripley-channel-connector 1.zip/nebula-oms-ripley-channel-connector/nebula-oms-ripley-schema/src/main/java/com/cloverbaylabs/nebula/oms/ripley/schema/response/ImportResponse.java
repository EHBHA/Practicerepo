package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import lombok.Data;

@Data
public class ImportResponse {

    private String importId;

    private String productImportId;
}
