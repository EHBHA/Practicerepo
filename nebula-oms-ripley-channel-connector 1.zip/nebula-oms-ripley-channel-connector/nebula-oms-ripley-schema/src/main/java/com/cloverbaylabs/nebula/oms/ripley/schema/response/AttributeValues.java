package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import java.util.List;
import lombok.Data;

@Data
public class AttributeValues{
    private List<ValuesListsItem> valuesLists;

    @Data
    public static class ValuesListsItem{
        private String code;
        private List<ValuesItem> values;
        private List<LabelTranslationsItem> labelTranslations;
        private String label;

        @Data
        public static class ValuesItem{
            private String code;
            private List<LabelTranslationsItem> labelTranslations;
            private String label;
        }

        @Data
        public static class LabelTranslationsItem{
            private String locale;
            private String value;
        }
    }
}