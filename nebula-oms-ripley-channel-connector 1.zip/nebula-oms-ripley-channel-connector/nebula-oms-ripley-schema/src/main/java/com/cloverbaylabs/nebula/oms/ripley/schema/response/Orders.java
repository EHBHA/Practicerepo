package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import java.util.List;
import lombok.Data;

@Data
public class Orders{
    private int totalCount;
    private List<OrdersItem> orders;

    @Data
    public static class OrdersItem{
        private String orderStateReasonCode;
        private Object channel;
        private boolean canCancel;
        private int leadtimeToShip;
        private Object orderTaxes;
        private String shippingDeadline;
        private String shippingCarrierStandardCode;
        private Object shippingTypeStandardCode;
        private String acceptanceDecisionDate;
        private boolean hasCustomerMessage;
        private String customerDebitedDate;
        private String orderStateReasonLabel;
        private String currencyIsoCode;
        private int price;
        private String shippingCarrierCode;
        private String lastUpdatedDate;
        private boolean customerDirectlyPaysSeller;
        private String shippingTracking;
        private int shippingPrice;
        private String shippingZoneCode;
        private String shippingCompany;
        private int totalCommission;
        private int totalPrice;
        private List<OrderAdditionalFieldsItem> orderAdditionalFields;
        private Object quoteId;
        private boolean hasInvoice;
        private boolean canShopShip;
        private String shippingTypeCode;
        private String commercialId;
        private String paymentWorkflow;
        private Object shippingPudoId;
        private Object deliveryDate;
        private boolean hasIncident;
        private Object orderRefunds;
        private String paymentType;
        private Promotions promotions;
        private String shippingTrackingUrl;
        private String shippingZoneLabel;
        private List<OrderLinesItem> orderLines;
        private String shippingTypeLabel;
        private String createdDate;
        private Fulfillment fulfillment;
        private boolean fullyRefunded;
        private String orderTaxMode;
        private String orderId;
        private String orderState;
        private Customer customer;

        @Data
        public static class Promotions{
            private List<Object> appliedPromotions;
            private int totalDeducedAmount;
        }

        @Data
        public static class Customer{
            private String firstname;
            private Object civility;
            private BillingAddress billingAddress;
            private ShippingAddress shippingAddress;
            private String customerId;
            private Object locale;
            private String lastname;


            @Data
            public static class ShippingAddress{
                private String country;
                private String firstname;
                private String city;
                private String zipCode;
                private String lastname;
                private Object countryIsoCode;
                private String street1;
                private String additionalInfo;
                private String street2;
                private Object company;
                private Object company2;
                private String state;
                private String phoneSecondary;
            }

            @Data
            public static class BillingAddress{
                private String country;
                private String firstname;
                private Object countryIsoCode;
                private String street1;
                private String city;
                private String street2;
                private Object company;
                private Object company2;
                private String state;
                private String phoneSecondary;
                private String zipCode;
                private String lastname;
            }
        }

        @Data
        public static class Fulfillment{
            private Center center;

            @Data
            public static class Center{
                private String code;
            }
        }

        @Data
        public static class OrderLinesItem{
            private List<Object> fees;
            private List<Object> shippingTaxes;
            private String categoryLabel;
            private String offerStateCode;
            private Object description;
            private List<Object> taxes;
            private boolean canRefund;
            private ShippingPriceAmountBreakdown shippingPriceAmountBreakdown;
            private List<RefundsItem> refunds;
            private Object shippingPriceAdditionalUnit;
            private String productSku;
            private Object receivedDate;
            private String offerSku;
            private int price;
            private String orderLineId;
            private String orderLineState;
            private String debitedDate;
            private Object shippingPriceUnit;
            private String lastUpdatedDate;
            private int commissionFee;
            private int shippingPrice;
            private List<Object> productMedias;
            private int quantity;
            private Object commissionRateVat;
            private int totalCommission;
            private int totalPrice;
            private String categoryCode;
            private int commissionVat;
            private int orderLineIndex;
            private PriceAmountBreakdown priceAmountBreakdown;
            private List<Object> orderLineAdditionalFields;
            private List<Object> cancelations;
            private List<CommissionTaxesItem> commissionTaxes;
            private int offerId;
            private String productTitle;
            private Object orderLineStateReasonLabel;
            private int priceUnit;
            private Object priceAdditionalInfo;
            private List<Object> promotions;
            private Object orderLineStateReasonCode;
            private Object shippedDate;
            private String productShopSku;
            private String createdDate;

            @Data
            public static class RefundsItem{
                private AmountBreakdown amountBreakdown;
                private int amount;
                private List<Object> fees;
                private String orderRefundId;
                private List<Object> shippingTaxes;
                private int quantity;
                private int commissionAmount;
                private int commissionTaxAmount;
                private List<Object> taxes;
                private List<CommissionTaxesItem> commissionTaxes;
                private ShippingAmountBreakdown shippingAmountBreakdown;
                private String reasonCode;
                private int shippingAmount;
                private int commissionTotalAmount;
                private String createdDate;
                private String id;
                private String state;
                private String refundState;

                @Data
                public static class ShippingAmountBreakdown{
                    private List<PartsItem> parts;
                }

                @Data
                public static class AmountBreakdown{
                    private List<PartsItem> parts;
                }
            }

            @Data
            public static class CommissionTaxesItem{
                private int amount;
                private String code;
                private Object rate;
            }

            @Data
            public static class PriceAmountBreakdown{
                private List<PartsItem> parts;
            }

            @Data
            public static class ShippingPriceAmountBreakdown{
                private List<PartsItem> parts;
            }

            @Data
            public static class PartsItem{
                private int amount;
                private boolean commissionable;
                private boolean payableToShop;
                private boolean debitableFromCustomer;
            }
        }

        @Data
        public static class OrderAdditionalFieldsItem{
            private String code;
            private String type;
            private String value;
        }

    }


}