package com.cloverbaylabs.nebula.oms.ripley.schema.base;

import lombok.Data;

@Data
public class RipleyError {

    private Integer status;

    private String message;
}
