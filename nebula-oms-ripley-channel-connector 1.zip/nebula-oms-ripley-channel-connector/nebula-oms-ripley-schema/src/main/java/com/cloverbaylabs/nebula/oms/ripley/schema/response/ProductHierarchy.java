package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductHierarchy {
    private List<HierarchiesItem> hierarchies;

    @Getter
    @Setter
    public static class HierarchiesItem{
        private String code;
        private int level;
        private List<LabelTranslationsItem> labelTranslations;
        private String parentCode;
        private String label;

        @Getter
        @Setter
        public static class LabelTranslationsItem{
            private String locale;
            private String value;
        }
    }
}