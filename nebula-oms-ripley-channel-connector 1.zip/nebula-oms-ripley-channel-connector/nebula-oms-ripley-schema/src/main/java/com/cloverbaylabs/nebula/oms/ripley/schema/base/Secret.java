package com.cloverbaylabs.nebula.oms.ripley.schema.base;

import lombok.Data;

@Data
public class Secret {

    private String apiKey;
}
