package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import java.util.List;
import lombok.Data;
import lombok.ToString;

@Data
public class ProductAttributes{
    private List<AttributesItem> attributes;

    @Data
    public static class AttributesItem{
        private String code;
        private String hierarchyCode;
        private String values;
        private String description;
        private String defaultValue;
        private String label;
        private String type;
        private boolean required;
        private String example;
        private List<DescriptionTranslationsItem> descriptionTranslations;
        private List<LabelTranslationsItem> labelTranslations;
        private boolean variant;
        private String typeParameter;
        private String valuesList;
        private String validations;
        private String transformations;

        @Data
        public static class DescriptionTranslationsItem{
            private String locale;
            private String value;
        }

        @Data
        public static class LabelTranslationsItem{
            private String locale;
            private String value;
        }
    }
}