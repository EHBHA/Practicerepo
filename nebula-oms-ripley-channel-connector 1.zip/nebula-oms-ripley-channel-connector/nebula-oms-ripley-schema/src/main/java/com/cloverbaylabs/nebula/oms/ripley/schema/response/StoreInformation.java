package com.cloverbaylabs.nebula.oms.ripley.schema.response;

import java.util.List;

import lombok.Data;

@Data
public class StoreInformation{
    private int evaluationsCount;
    private PaymentDetails paymentDetails;
    private boolean freeShipping;
    private String shopState;
    private int approvalDelay;
    private String description;
    private ContactInformations contactInformations;
    private int approvalRate;
    private BillingInfo billingInfo;
    private boolean premium;
    private List<String> shippingZones;
    private String currencyIsoCode;
    private String returnPolicy;
    private String logo;
    private String lastUpdatedDate;
    private List<ShopAdditionFields> shopAdditionalFields;
    private List<ShippingsItem> shippings;
    private String dateCreated;
    private ProDetails proDetails;
    private String banner;
    private Object closedTo;
    private String shopName;
    private int ordersCount;
    private int shopId;
    private long orderMessagesResponseDelay;
    private List<String> channels;
    private boolean isProfessional;
    private double grade;
    private int offersCount;
    private Object closedFrom;
    private String shippingCountry;
    private List<String> shippingTypes;

    @Data
    public static class ShopAdditionFields {
        private String code;
        private String type;
        private String value;
    }

    @Data
    public static class ProDetails{
        private String identificationNumber;
        private Object vATNumber;
        private String corporateName;
        private Object taxIdentificationNumber;
    }

    @Data
    public static class PaymentDetails{
        private int pendingBalance;
        private int payableBalance;
        private int paidBalance;
    }

    @Data
    public static class ContactInformations{
        private String country;
        private String firstname;
        private String civility;
        private String city;
        private String lastname;
        private Object phone;
        private String street1;
        private String state;
        private Object street2;
        private Object fax;
        private String email;
        private Object phoneSecondary;
        private Object webSite;
    }

    @Data
    public static class ShippingsItem{
        private String shippingZoneCode;
        private String shippingZoneLabel;
        private String shippingTypeLabel;
        private String shippingTypeCode;
        private Object shippingFreeAmount;
    }

    @Data
    public static class BillingInfo{
        private Object owner;
        private Object iban;
        private Object bankName;
        private Object bankStreet;
        private Object bic;
        private Object zipCode;
        private Object bankCity;
    }
}