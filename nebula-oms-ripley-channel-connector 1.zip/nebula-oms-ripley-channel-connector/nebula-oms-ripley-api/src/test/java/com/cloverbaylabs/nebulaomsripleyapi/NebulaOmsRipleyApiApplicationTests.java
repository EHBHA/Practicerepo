package com.cloverbaylabs.nebulaomsripleyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NebulaOmsRipleyApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
