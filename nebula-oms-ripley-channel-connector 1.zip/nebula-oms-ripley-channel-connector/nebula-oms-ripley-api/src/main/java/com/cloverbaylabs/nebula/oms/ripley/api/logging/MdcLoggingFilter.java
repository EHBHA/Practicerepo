package com.cloverbaylabs.nebula.oms.ripley.api.logging;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

/**
 * class to set the mdc
 */
@Component
public class MdcLoggingFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        try {
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            MDC.put("x-tenant-id", httpRequest.getHeader("x-tenant-id"));
            MDC.put("x-client-id", httpRequest.getHeader("x-client-id"));
            MDC.put("x-trace-id", httpRequest.getHeader("x-trace-id"));
            MDC.put("x-business-group-id", httpRequest.getHeader("x-business-group-id"));

            chain.doFilter(request, response);
        } finally {
            MDC.clear();
        }
    }
}
