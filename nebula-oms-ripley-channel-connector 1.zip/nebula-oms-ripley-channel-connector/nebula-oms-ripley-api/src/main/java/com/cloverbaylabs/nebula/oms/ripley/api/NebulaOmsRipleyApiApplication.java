package com.cloverbaylabs.nebula.oms.ripley.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.cloverbaylabs", "com.cloverbaylabs.lib.authgateway"})
public class NebulaOmsRipleyApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(NebulaOmsRipleyApiApplication.class, args);
    }

}
