package com.cloverbaylabs.nebula.oms.ripley.api.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * Class to create config for Swagger UI
 */
@Configuration
public class OpenApiConfig {

    /**
     *
     * @return OpenApi Instance
     */
    @Bean
    public OpenAPI customOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("Nebula OMS Ripley Connector")
                        .version("1.0.0")
                        .description("APIs exposed for Nebula OMS Ripley Connector"));
    }
}
