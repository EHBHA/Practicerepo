package com.cloverbaylabs.nebula.oms.ripley.api.controller;

import java.time.LocalDateTime;

import com.cloverbaylabs.nebula.oms.ripley.api.auth.Scope;
import com.cloverbaylabs.nebula.oms.ripley.api.logging.TrackTime;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.OrderService;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.Orders;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.BUSINESS_GROUP_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.CLIENT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TENANT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TRACE_ID;

@RestController
@RequestMapping("api/orders")
@RequiredArgsConstructor
@Tag(name = "3.ORDER CONTROLLER",
        description = "APIs exposed for orders on ripley platform")
public class OrderController {

    private final OrderService orderService;

    @TrackTime
    @Operation(summary = "Get orders on Ripley", method = "GET")
    @Scope("ne:oms:ripley:orders:get")
    @GetMapping("v1")
    public ResponseEntity<Orders> getOrders(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(name = "start_update_date",
                    required = false) LocalDateTime startUpdateDate,
            @RequestParam(name = "end_update_date",
                    required = false) LocalDateTime endUpdateDate,
            @RequestParam(name = "paginate", defaultValue = "true") boolean paginate,
            @RequestParam(name = "offset", defaultValue = "0") int offset,
            @RequestParam(name = "limit", defaultValue = "10") int limit) {
        return ResponseEntity
                .ok(orderService.getOrders(businessGroupId, tenantId,
                        startUpdateDate, endUpdateDate,
                        paginate, offset, limit));
    }


}
