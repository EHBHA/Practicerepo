package com.cloverbaylabs.nebula.oms.ripley.api.controller;

import com.cloverbaylabs.nebula.oms.ripley.api.auth.Scope;
import com.cloverbaylabs.nebula.oms.ripley.api.logging.TrackTime;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.InventoryService;
import com.cloverbaylabs.nebula.oms.ripley.schema.dto.OfferUpdateDto;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ImportResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.BUSINESS_GROUP_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.CLIENT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TENANT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TRACE_ID;

@RestController
@RequestMapping("api/inventory")
@RequiredArgsConstructor
@Tag(name = "4.INVENTORY CONTROLLER",
        description = "APIs exposed to sync inventory on ripley platform")
public class InventoryController {

    private final InventoryService inventoryService;

    @TrackTime
    @Operation(summary = "Sync inventory on Ripley", method = "POST")
    @Scope("ne:oms:ripley:inventory:sync")
    @PostMapping("v1")
    public ResponseEntity<ImportResponse> syncInventory(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody @Valid OfferUpdateDto requestBody) {
        return ResponseEntity
                .ok(inventoryService.syncInventory(businessGroupId, tenantId,
                        requestBody));
    }
}
