package com.cloverbaylabs.nebula.oms.ripley.api.controller;

import java.util.List;

import com.cloverbaylabs.nebula.oms.ripley.api.auth.Scope;
import com.cloverbaylabs.nebula.oms.ripley.api.logging.TrackTime;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.ProductService;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.StoreService;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.AttributeValues;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.OfferErrorStatus;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductAttributes;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductErrorStatus;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductHierarchy;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductImportResponse;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductOffers;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.StoreDeals;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.StoreInformation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.BUSINESS_GROUP_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.CLIENT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TENANT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TRACE_ID;

@RestController
@RequestMapping("api")
@RequiredArgsConstructor
@Tag(name = "2.STORE CONTROLLER",
        description = "APIs exposed to get store information from ripley platform")
public class StoreController {

    private final StoreService storeService;

    @TrackTime
    @Operation(summary = "Get Store information from Ripley", method = "GET")
    @Scope("ne:oms:ripley:stores:info")
    @GetMapping("store-information/v1")
    public ResponseEntity<StoreInformation> getStoreInformation(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token) {
        return ResponseEntity
                .ok(storeService
                        .getStoreInformation(businessGroupId,
                                tenantId));
    }

}
