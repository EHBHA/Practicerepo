package com.cloverbaylabs.nebula.oms.ripley.api.controller;

import java.util.List;

import com.cloverbaylabs.nebula.oms.ripley.api.auth.Scope;
import com.cloverbaylabs.nebula.oms.ripley.api.logging.TrackTime;
import com.cloverbaylabs.nebula.oms.ripley.core.service.intf.ProductService;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.AttributeValues;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ImportResponse;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.OfferErrorStatus;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductAttributes;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductErrorStatus;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductHierarchy;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.ProductOffers;
import com.cloverbaylabs.nebula.oms.ripley.schema.response.StoreDeals;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.BUSINESS_GROUP_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.CLIENT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TENANT_ID;
import static com.cloverbaylabs.framework.utilities.constant.HeaderKeys.TRACE_ID;

@RestController
@RequestMapping("api/products")
@RequiredArgsConstructor
@Tag(name = "1.PRODUCT CONTROLLER",
        description = "APIs exposed to sync products on ripley platform")
public class ProductController {

    private final ProductService productService;

    @TrackTime
    @Operation(summary = "Bulk Import products on Ripley", method = "POST")
    @Scope("ne:oms:ripley:products:import")
    @PostMapping("v1")
    public ResponseEntity<ImportResponse> createProduct(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestPart("file") MultipartFile file) {
        return ResponseEntity
                .ok(productService.importProducts(businessGroupId, tenantId,
                        file));
    }

    @TrackTime
    @Operation(summary = "Get Product offer status from Ripley", method = "GET")
    @Scope("ne:oms:ripley:products:offers:status")
    @GetMapping("offers/v1/{import_id}")
    public ResponseEntity<OfferErrorStatus> getOfferErrorStatus(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @PathVariable("import_id") String importId) {
        return ResponseEntity
                .ok(productService.getOfferErrorStatus(businessGroupId, tenantId,
                        importId));
    }

    @TrackTime
    @Operation(summary = "Get Product status from Ripley", method = "GET")
    @Scope("ne:oms:ripley:products:status")
    @GetMapping("v1/{import_id}")
    public ResponseEntity<ProductErrorStatus> getProductsErrorStatus(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @PathVariable("import_id") String importId) {
        return ResponseEntity
                .ok(productService.getProductErrorStatus(businessGroupId, tenantId,
                        importId));
    }

    @TrackTime
    @Operation(summary = "Get Product hierarchies from Ripley", method = "GET")
    @Scope("ne:oms:ripley:products:hierarchies")
    @GetMapping("hierarchies/v1")
    public ResponseEntity<ProductHierarchy> getProductHierarchies(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token) {
        return ResponseEntity
                .ok(productService.getHierarchies(businessGroupId, tenantId));
    }

    @TrackTime
    @Operation(summary = "Get Product attributes from Ripley", method = "GET")
    @Scope("ne:oms:ripley:products:attributes")
    @GetMapping("attributes/v1")
    public ResponseEntity<ProductAttributes> getProductAttributes(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token) {
        return ResponseEntity
                .ok(productService.getProductAttributes(businessGroupId, tenantId));
    }

    @TrackTime
    @Operation(summary = "Get product attributes values from Ripley", method = "GET")
    @Scope("ne:oms:ripley:product:attributes:values")
    @GetMapping("attributes/values/v1")
    public ResponseEntity<AttributeValues> getAttributeValues(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token) {
        return ResponseEntity
                .ok(productService.getAttributeValues(businessGroupId, tenantId));
    }

    @TrackTime
    @Operation(summary = "Get product store deals from Ripley", method = "GET")
    @Scope("ne:oms:ripley:product:store-deals")
    @GetMapping("store-deals/v1")
    public ResponseEntity<StoreDeals> getStoreDeals(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(name = "sku", required = false) String sku,
            @RequestParam(name = "paginate", defaultValue = "true") boolean paginate,
            @RequestParam(name = "offset", defaultValue = "0") int offset,
            @RequestParam(name = "limit", defaultValue = "10") int limit) {
        return ResponseEntity
                .ok(productService.getStoreDeals(businessGroupId, tenantId,
                        sku, paginate, offset, limit));
    }

    @TrackTime
    @Operation(summary = "Get product offers from Ripley", method = "GET")
    @Scope("ne:oms:ripley:product:offers")
    @GetMapping("offers/v1")
    public ResponseEntity<ProductOffers> getProductOffers(
            @RequestHeader(BUSINESS_GROUP_ID) String businessGroupId,
            @RequestHeader(TENANT_ID) String tenantId,
            @RequestHeader(CLIENT_ID) String clientId,
            @RequestHeader(TRACE_ID) String traceId,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestParam(name = "product_ids") List<String> productIds) {
        return ResponseEntity
                .ok(productService.getProductOffers(businessGroupId, tenantId,
                        productIds));
    }




}
