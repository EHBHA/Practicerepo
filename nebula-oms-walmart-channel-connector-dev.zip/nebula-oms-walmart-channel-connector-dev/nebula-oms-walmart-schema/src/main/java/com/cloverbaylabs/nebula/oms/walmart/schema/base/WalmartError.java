package com.cloverbaylabs.nebula.oms.walmart.schema.base;


import lombok.Data;

@Data
public class WalmartError {

    private Integer status;

    private String message;
}
