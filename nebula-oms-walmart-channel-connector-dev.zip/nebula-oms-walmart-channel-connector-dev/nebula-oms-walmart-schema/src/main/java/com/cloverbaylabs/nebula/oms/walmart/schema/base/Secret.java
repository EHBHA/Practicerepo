package com.cloverbaylabs.nebula.oms.walmart.schema.base;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Secret {

    private String clientId;

    private String clientSecret;

}
