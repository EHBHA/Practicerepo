package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class UpdatePrice {
    private String status;
    private Header header;
    private List<Object> errors;
    private Payload payload;

    @Data
    public static class Header {
        private Map<String, Object> headerAttributes;
    }

    @Data
    public static class Payload {
        private int errorCount;
        private List<Error> errors;
        private List<ResponsePayload> responsePayload;
    }

    @Data
    public static class Error {
        private String description;
        private String severity;
        private String category;
        private List<Object> causes;
        private Map<String, Object> errorIdentifiers;
    }

    @Data
    public static class ResponsePayload {
        private String sku;
        private String currency;
        private double amount;
        private String message;
    }
}
