package com.cloverbaylabs.nebula.oms.walmart.schema.inventory.dto;

import lombok.Data;

@Data
public class SingleInventoryDto {
    private String sku;
    private Quantity quantity;

    @Data
    public static class Quantity {
        private String unit;
        private int amount;
    }
}
