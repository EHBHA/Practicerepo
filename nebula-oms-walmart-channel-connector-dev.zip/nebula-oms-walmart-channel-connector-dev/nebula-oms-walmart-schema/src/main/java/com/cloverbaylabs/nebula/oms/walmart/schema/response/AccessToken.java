package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import lombok.Data;

@Data
public class AccessToken {
    private String accessToken;
    private String tokenType;
    private int expiresIn;
}
