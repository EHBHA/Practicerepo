package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class FeedErrorSummary {

    private String status;
    private Header header;
    private List<JsonNode> errors;
    private Payload payload;

    @Data
    public static class Header {
        private Map<String, JsonNode> headerAttributes;

    }

    @Data
    public static class Payload {
        private int totalResults;
        private int offset;
        private int limit;
        private List<Result> results;

    }

    @Data
    public static class Result {
        private String feedId;
        private String itemId;
        private String itemStatus;
        private String itemState;
        private String createDate;
        private String modifiedDtm;
        private String itemProcessingType;
        private List<String> gtin;
        private List<String> error;
    }
}
