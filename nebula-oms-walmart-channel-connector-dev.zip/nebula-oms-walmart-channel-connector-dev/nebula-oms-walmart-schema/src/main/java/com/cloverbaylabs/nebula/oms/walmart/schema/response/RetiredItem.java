package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class RetiredItem {

    private String status;
    private Header header;
    private List<Object> errors;
    private Payload payload;

    @Data
    public static class Header {
        private Map<String, Object> headerAttributes;
    }

    @Data
    public static class Payload {
        private List<ErrorDetail> errors;
        private List<SuccessDetail> success;
    }

    @Data
    public static class ErrorDetail {
        private String sku;
        private String description;

    }

    @Data
    public static class SuccessDetail {
        private String sku;
        private String description;

    }
}
