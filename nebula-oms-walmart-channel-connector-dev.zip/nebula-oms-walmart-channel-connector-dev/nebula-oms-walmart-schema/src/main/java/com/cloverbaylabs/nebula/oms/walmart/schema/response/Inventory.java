package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import lombok.Data;

@Data
public class Inventory {
    private String sku;
    private Quantity quantity;

    @Data
    public static class Quantity {
        private String unit;
        private int amount;
    }
}
