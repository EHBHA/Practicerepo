package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import lombok.Data;

import java.util.List;


@Data
public class VariantGroupItemCount {
    private int status;
    private List<VariantGroupDto> payload;

    @Data
    public static class VariantGroupDto {
        private String variantGroupId;
        private int count;
    }
}
