package com.cloverbaylabs.nebula.oms.walmart.schema.inventory.dto;

import lombok.Data;

import java.util.List;

@Data
public class BulkInventoryDto {
    private List<SingleInventoryDto> Inventory;

    private InventoryHeader InventoryHeader;

    @Data
    public static class InventoryHeader{
        private String version;
    }
}
