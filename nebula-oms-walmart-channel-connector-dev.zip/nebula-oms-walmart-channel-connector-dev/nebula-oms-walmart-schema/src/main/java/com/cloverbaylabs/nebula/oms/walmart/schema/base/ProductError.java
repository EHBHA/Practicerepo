package com.cloverbaylabs.nebula.oms.walmart.schema.base;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class ProductError {
    private List<ErrorDetail> error;

    @Data
    public static class ErrorDetail {
        private String code;
        private String field;
        private String description;
        private String info;
        private String severity;
        private String category;
        private List<Object> causes;
        private Map<String, Object> errorIdentifiers;

    }
}
