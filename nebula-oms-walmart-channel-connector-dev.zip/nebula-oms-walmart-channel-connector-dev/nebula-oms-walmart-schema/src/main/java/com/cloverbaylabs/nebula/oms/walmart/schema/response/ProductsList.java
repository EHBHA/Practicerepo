package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import lombok.Data;

import java.util.List;

@Data
public class ProductsList {
    private List<Item> ItemResponse;
    private int totalItems;

    @Data
    public static class Item {
        private String mart;
        private String sku;
        private String upc;
        private String wpid;
        private String gtin;
        private String productName;
        private String shelf;
        private String productType;
        private Price price;
        private String publishedStatus;
        private String lifecycleStatus;
        private String variantGroupId;
        private VariantGroupInfo variantGroupInfo;
    }

    @Data
    public static class Price {
        private String currency;
        private int amount;

    }

    @Data
    public static class VariantGroupInfo {
        private boolean isPrimary;
        private List<GroupingAttribute> groupingAttributes;

    }

    @Data
    public static class GroupingAttribute {
        private String name;
        private String value;

    }
}
