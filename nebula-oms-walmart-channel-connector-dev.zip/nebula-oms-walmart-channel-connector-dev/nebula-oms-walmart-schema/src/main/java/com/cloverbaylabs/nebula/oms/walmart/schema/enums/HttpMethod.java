package com.cloverbaylabs.nebula.oms.walmart.schema.enums;

import lombok.Getter;

@Getter
public enum HttpMethod {

    POST,
    PUT,
    PATCH,
    DELETE,
    GET
}
