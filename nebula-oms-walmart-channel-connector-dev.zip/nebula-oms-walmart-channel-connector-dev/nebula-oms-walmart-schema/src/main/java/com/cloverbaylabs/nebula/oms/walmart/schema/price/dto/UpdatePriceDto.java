package com.cloverbaylabs.nebula.oms.walmart.schema.price.dto;

import lombok.Data;

import java.util.List;

@Data
public class UpdatePriceDto {
    private List<String> skus;
    private String amount;
}
