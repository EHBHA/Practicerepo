package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class FeedStatus {
    private String status;
    private Header header;
    private List<JsonNode> errors;
    private FeedPayload payload;

    @Data
    public static class Header {
        private Map<String, JsonNode> headerAttributes;

    }

    @Data
    public static class FeedPayload {
        private int totalResults;
        private int offset;
        private int limit;
        private FeedResults results;
    }

    @Data
    public static class FeedResults {
        private List<FeedItem> feed;

    }

    @Data
    public static class FeedItem {
        private String feedId;
        private String feedType;
        private int itemsReceived;
        private int itemsSucceeded;
        private int itemsFailed;
        private int itemsProcessing;
        private String feedStatus;
        private String feedDate;
        private String modifiedDtm;
        private String batchId;
        private String fileName;
        private int itemDataErrorCount;
        private int itemSystemErrorCount;
        private int itemTimeoutErrorCount;

    }
}
