package com.cloverbaylabs.nebula.oms.walmart.schema.base;

import com.cloverbaylabs.nebula.oms.walmart.schema.enums.HttpMethod;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ConnectorDetails {
    private String businessGroupId;

    private String tenantId;

    private String endpointUrl;

    private HttpMethod httpMethod;

    private String acceptType;

    private String contentType;
}
