package com.cloverbaylabs.nebula.oms.walmart.schema.response;

import lombok.Data;

@Data
public class Feed {
    private String feedId;
}
