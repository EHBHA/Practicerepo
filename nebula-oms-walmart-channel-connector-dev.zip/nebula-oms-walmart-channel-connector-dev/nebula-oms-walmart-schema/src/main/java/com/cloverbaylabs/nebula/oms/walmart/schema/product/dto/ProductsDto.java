package com.cloverbaylabs.nebula.oms.walmart.schema.product.dto;

import lombok.Data;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Data
public class ProductsDto {

    private MPItemFeedHeader MPItemFeedHeader;
    private List<MPItem> MPItem;

    @Data
    public static class MPItemFeedHeader {
        private String subCategory;
        private String sellingChannel;
        private String processMode;
        private String mart;
        private String locale;
        private String version;
        private String subset;
    }

    @Data
    public static class MPItem {
        private Orderable Orderable;
        private Visible Visible;
    }

    @Data
    public static class Orderable {
        private String sku;
        private ProductIdentifiers productIdentifiers;
        private String brand;
        private List<String> countryOfOriginAssembly;
        private List<String> keyFeatures;
        private String shortDescription;
        private String manufacturer;
        private String warrantyText;
        private String condition;
        private String startDate;
        private String endDate;
        private List<ExternalProductIdentifier> externalProductIdentifier;
        private double price;
        private double shippingDimensionsHeight;
        private double ShippingDimensionsWidth;
        private double ShippingDimensionsDepth;
        private double ShippingWeight;
        private List<String> productSecondaryImageURL;
        private String productName;
        private String mainImageUrl;
    }

    @Data
    public static class ProductIdentifiers {
        private String productIdType;
        private String productId;
    }

    @Data
    public static class ExternalProductIdentifier {
        private String externalProductIdType;
    }

    @Data
    public static class Visible {
        private Map<String, Object> dynamicAttributes = new HashMap<>();

        @JsonAnySetter
        public void set(String key, Object value) {
            dynamicAttributes.put(key, value);
        }

        @JsonAnyGetter
        public Map<String, Object> get() {
            return dynamicAttributes;
        }
    }
}
