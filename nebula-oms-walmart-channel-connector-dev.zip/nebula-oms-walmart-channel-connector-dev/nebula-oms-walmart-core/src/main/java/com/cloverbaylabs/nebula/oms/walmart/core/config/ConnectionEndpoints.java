package com.cloverbaylabs.nebula.oms.walmart.core.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 *  Walmart Api endpoints
 */
@Getter
@Component
public class ConnectionEndpoints {

    @Value("${walmart.url.products.create-products}")
    private String createProduct;

    @Value("${walmart.url.products.get-all-products}")
    private String allProducts;

    @Value("${walmart.url.products.delete-product}")
    private String deleteProduct;

    @Value("${walmart.url.products.get-product}")
    private String singleProduct;

    @Value("${walmart.url.products.product-count-by-group}")
    private String itemCountByGroup;

    @Value("${walmart.url.token.fetch-access-token}")
    private String fetchAccessToken;

    @Value("${walmart.url.token.token-detail}")
    private String tokenDetail;

    @Value("${walmart.url.feed.feed-status}")
    private String feedStatus;

    @Value("${walmart.url.feed.feed-error-report}")
    private String feedErrorReport;

    @Value("${walmart.url.inventory.inventory}")
    private String inventory;

    @Value("${walmart.url.inventory.inventory}")
    private String updateSingleInventory;

    @Value("${walmart.url.inventory.update-bulk-inventory}")
    private String updateBulkInventory;


}
