package com.cloverbaylabs.nebula.oms.walmart.core.service.intf;

import com.cloverbaylabs.nebula.oms.walmart.schema.base.Secret;

public interface SecretManagerService {
    Secret getSecret(String businessGroupId, String tenantId);
}
