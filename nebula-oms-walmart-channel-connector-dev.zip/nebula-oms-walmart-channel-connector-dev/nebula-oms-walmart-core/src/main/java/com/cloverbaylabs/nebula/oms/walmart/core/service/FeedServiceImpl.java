package com.cloverbaylabs.nebula.oms.walmart.core.service;

import com.cloverbaylabs.nebula.oms.walmart.core.config.ConnectionEndpoints;
import com.cloverbaylabs.nebula.oms.walmart.core.facade.intf.WalmartConnectorFacade;
import com.cloverbaylabs.nebula.oms.walmart.core.service.intf.FeedService;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.walmart.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.FeedErrorSummary;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.FeedStatus;
import lombok.RequiredArgsConstructor;
import okhttp3.MediaType;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import static com.cloverbaylabs.nebula.oms.walmart.core.util.UrlUtil.buildUrl;

@Service
@RequiredArgsConstructor
public class FeedServiceImpl implements FeedService {

    private static final String apiType = "Feed";

    private final ConnectionEndpoints urls;

    private final WalmartConnectorFacade walmartConnectorFacade;

    private static final String APPLICATION_JSON = "application/json";

    private final MediaType mediaTypeJson = MediaType.parse(APPLICATION_JSON);

    @Override
    public FeedStatus getAllFeedStatuses(String businessGroupId, String tenantId, String feedId, String feedType, String feedStatus, String offset, String limit) throws URISyntaxException {

        Map<String, Object> params = new HashMap<>();
        params.put("feedId", feedId);
        params.put("feedType", feedType);
        params.put("feedStatus", feedStatus);
        params.put("offset", offset);
        params.put("limit", limit);

        String url = buildUrl(urls.getFeedStatus(), params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .tenantId(tenantId)
                .businessGroupId(businessGroupId)
                .httpMethod(HttpMethod.GET)
                .acceptType(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .endpointUrl(url)
                .build();

        return walmartConnectorFacade.walmartApiCall(connectorDetails, null, FeedStatus.class, apiType);
    }

    @Override
    public FeedErrorSummary getFeedErrorSummary(String businessGroupId, String tenantId, String feedId) throws URISyntaxException {

        Map<String, Object> params = new HashMap<>();
        params.put("feedId", feedId);

        String url = buildUrl(urls.getFeedErrorReport(), params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .tenantId(tenantId)
                .businessGroupId(businessGroupId)
                .httpMethod(HttpMethod.GET)
                .acceptType(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .endpointUrl(url)
                .build();

        return walmartConnectorFacade.walmartApiCall(connectorDetails, null, FeedErrorSummary.class, apiType);
    }
}
