package com.cloverbaylabs.nebula.oms.walmart.core.service.intf;

import com.cloverbaylabs.nebula.oms.walmart.schema.product.dto.ProductsDto;
import com.cloverbaylabs.nebula.oms.walmart.schema.product.dto.RetireItemDto;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.Feed;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.ProductsList;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.RetiredItem;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.VariantGroupItemCount;

import java.net.URISyntaxException;


public interface ProductService {

    Feed createProduct(String businessGroupId, String tenantId, String feedType, ProductsDto productsDto) throws URISyntaxException;

    RetiredItem retireItem(String businessGroupId, String tenantId, RetireItemDto retiredItem);

    ProductsList getOneItem(String businessGroupId, String tenantId, String sku, String productIdType) throws URISyntaxException;

    ProductsList getAllItems(String businessGroupId, String tenantId);

    VariantGroupItemCount getItemCountByVariant(String businessGroupId, String tenantId, String variantGroupId) throws URISyntaxException;

}
