package com.cloverbaylabs.nebula.oms.walmart.core.facade.intf;

import com.cloverbaylabs.nebula.oms.walmart.schema.base.Secret;

public interface TokenFacade {

    Secret fetchSecret(String businessGroupId, String tenantId);
    String getAccessToken(String businessGroupId, String tenantId);
}
