package com.cloverbaylabs.nebula.oms.walmart.core.util;

import com.cloverbaylabs.nebula.oms.walmart.core.exception.WalmartApiException;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.FeedError;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.InventoryError;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.ProductError;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.WalmartError;
import com.cloverbaylabs.nebula.oms.walmart.schema.enums.HttpMethod;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
@RequiredArgsConstructor
public class HttpClientInvoker {

    private final OkHttpClient httpClient;

    private final JsonConvertor jsonConvertor;

    private static final String PRODUCT = "Product";

    private static final String FEED = "Feed";

    private static final String ORDER = "Order";

    private static final String PRICE = "Price";

    private static final String INVENTORY = "Inventory";

    private static final String AUTHORIZATION = "Authorization";

    public <T> T post(String url, Headers headers,
                      RequestBody requestPayload, Class<T> responseType, String apiType) {
        return executeRequest(buildRequest(url, headers,
                requestPayload, HttpMethod.POST.toString()), responseType, apiType);
    }

    public <T> T get(String url, Headers headers,  Class<T> responseType, String apiType) {
        return executeRequest(new Request.Builder().url(url).headers(headers)
                .get().build(), responseType, apiType);
    }

    public <T> T put(String url, Headers headers,
                     RequestBody requestPayload, Class<T> responseType, String apiType) {
        return executeRequest(buildRequest(url, headers,
                requestPayload, HttpMethod.PUT.toString()), responseType, apiType);
    }

    public <T> T delete(String url, Headers headers,
                        Class<T> responseType, String apiType) {
        return executeRequest(new Request.Builder().url(url)
                .headers(headers).delete().build(), responseType, apiType);
    }

    private <T> Request buildRequest(String url,
                                 Headers headers, RequestBody requestBody,
                                 String method) {
        try {

            Request.Builder requestBuilder = new Request.Builder()
                    .url(url)
                    .method(method, requestBody);
            if (headers != null) {
                requestBuilder.headers(headers);
            }
            return requestBuilder.build();
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialize request payload", e);
        }
    }

    private <T> T executeRequest(Request request, Class<T> responseClass, String apiType) {
        long startTime = System.currentTimeMillis();
        logRequest(request.method(), request.headers(), request.url().toString(),
                request.body() != null ? request.body().toString() : null);
        try (Response response = httpClient.newCall(request).execute()) {
            long elapsedTime = System.currentTimeMillis() - startTime;

            String responseBody = response.body().string();

            if (!response.isSuccessful()) {
                logErrorResponse(request.method(), request.url().toString(),
                        response.code(), responseBody, elapsedTime);

                WalmartError walmartError = new WalmartError();

                switch (apiType){
                    case PRODUCT :
                        ProductError productError = jsonConvertor.convertToObject(responseBody, ProductError.class);
                        if(!productError.getError().isEmpty()){
                            walmartError.setStatus(response.code());
                            walmartError.setMessage(productError.getError().get(0).getInfo());
                            throw new WalmartApiException(walmartError);
                        }
                        break;

                    case ORDER :

                        break;

                    case INVENTORY :
                        InventoryError inventoryError = jsonConvertor.convertToObject(responseBody, InventoryError.class);
                        if(inventoryError != null){
                            walmartError.setStatus(response.code());
                            walmartError.setMessage(inventoryError.getMessage());
                            throw new WalmartApiException(walmartError);
                        }
                        break;

                    case FEED :
                        FeedError feedError = jsonConvertor.convertToObject(responseBody, FeedError.class);
                        if(!feedError.getErrors().isEmpty()){
                            walmartError.setStatus(response.code());
                            walmartError.setMessage(feedError.getErrors().get(0).getInfo());
                            throw new WalmartApiException(walmartError);
                        }
                        break;

                    case PRICE : break;
                    case AUTHORIZATION : throw new RuntimeException("Something went wrong with API");
                    default: throw new RuntimeException("Something went wrong");
                }
            }

            logResponse(request.method(), request.url().toString(), responseBody, elapsedTime);
            return jsonConvertor.convertToObject(responseBody,
                    responseClass);
        } catch (IOException e) {
            throw new RuntimeException("Failed to execute request", e);
        }
    }

    private void logRequest(String method, Headers headers,
                            String url, String requestBody) {
        log.info("HTTP {} Request - Headers: {}, URL: {}, Request Body: {}",
                method, headers.toString(), url, requestBody);
    }

    private void logResponse(String method, String url, String responseBody, long elapsedTime) {
        log.info("HTTP {} Response - URL: {}, Response Body: {}, Time Taken: {} ms",
                method, url, responseBody, elapsedTime);
    }

    private void logErrorResponse(String method, String url, int statusCode,
                                  String responseBody, long elapsedTime) {
        log.error("HTTP {} Error - URL: {}, Status Code: {}, Response Body: {}, Time Taken: {} ms",
                method, url, statusCode, responseBody, elapsedTime);
    }

    public <T> T sendRequest(HttpMethod method,
                             String requestUrl, Headers headers,
                             RequestBody body, Class<T> responseType, String apiType) {
        return switch (method) {
            case POST -> post(requestUrl, headers, body, responseType, apiType);
            case PUT, PATCH -> put(requestUrl, headers, body, responseType, apiType);
            case DELETE -> delete(requestUrl, headers, responseType, apiType);
            case GET -> get(requestUrl, headers, responseType, apiType);
        };

    }
}
