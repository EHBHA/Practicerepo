package com.cloverbaylabs.nebula.oms.walmart.core.facade;

import com.cloverbaylabs.nebula.oms.walmart.core.facade.intf.TokenFacade;
import com.cloverbaylabs.nebula.oms.walmart.core.facade.intf.WalmartConnectorFacade;
import com.cloverbaylabs.nebula.oms.walmart.core.util.HttpClientInvoker;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.Secret;
import com.cloverbaylabs.nebula.oms.walmart.schema.enums.HttpMethod;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import okhttp3.RequestBody;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;

@Component
@Slf4j
@RequiredArgsConstructor
public class WalmartConnectorFacadeImpl implements WalmartConnectorFacade {

    private final HttpClientInvoker httpClientInvoker;

    private final TokenFacade tokenFacade;
    private static final String SERVICE_NAME = "";

    private static final String MARKET = "cl";

    private static final String ORDER = "Order";

    private static final String PRICE = "Price";

    @Override
    public <T> T walmartApiCall(ConnectorDetails connectorDetails, RequestBody requestBody,
                                 Class<T> responseClass, String apiType) {

        Headers.Builder headersBuilder = new Headers.Builder()
                .add("WM_SEC.ACCESS_TOKEN", tokenFacade.getAccessToken(connectorDetails.getBusinessGroupId(), connectorDetails.getTenantId()))
                .add("WM_MARKET", MARKET)
                .add("WM_QOS.CORRELATION_ID", UUID.randomUUID().toString())
                .add("WM_SVC.NAME", SERVICE_NAME)
                .add("accept", connectorDetails.getAcceptType());

        if(connectorDetails.getHttpMethod().equals(HttpMethod.POST)){
                headersBuilder.add("content-type", connectorDetails.getContentType());
        }

        if(apiType.equals(ORDER)){
            Secret secret = tokenFacade.fetchSecret(connectorDetails.getBusinessGroupId(), connectorDetails.getTenantId());
            String credentials = secret.getClientId() + ":" + secret.getClientSecret();
            String authorizationCode = Base64.getEncoder()
                    .encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
            headersBuilder.add("Authorization", "Basic " + authorizationCode);
        }

        Headers headers = headersBuilder.build();

        if (requestBody == null) {
            requestBody = RequestBody.create(new byte[]{}, null);
        }

        return httpClientInvoker.sendRequest(connectorDetails.getHttpMethod(), connectorDetails.getEndpointUrl(), headers, requestBody, responseClass, apiType);
    }
}
