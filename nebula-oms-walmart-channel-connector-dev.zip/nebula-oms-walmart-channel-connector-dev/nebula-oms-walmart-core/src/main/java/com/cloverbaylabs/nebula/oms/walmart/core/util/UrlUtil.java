package com.cloverbaylabs.nebula.oms.walmart.core.util;

import lombok.SneakyThrows;
import org.apache.hc.core5.net.URIBuilder;
import java.net.URISyntaxException;
import java.util.Map;

public class UrlUtil {

    @SneakyThrows
    public static String buildUrl(String baseUrl, Map<String, Object> params)
            throws URISyntaxException {
        URIBuilder uriBuilder = new URIBuilder(baseUrl);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            if (entry.getValue() != null) {
                uriBuilder.addParameter(entry.getKey(),
                        entry.getValue().toString());
            }
        }
        return uriBuilder.build().toString();
    }
}
