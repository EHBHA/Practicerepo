package com.cloverbaylabs.nebula.oms.walmart.core.service.intf;

import com.cloverbaylabs.nebula.oms.walmart.schema.inventory.dto.BulkInventoryDto;
import com.cloverbaylabs.nebula.oms.walmart.schema.inventory.dto.SingleInventoryDto;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.Feed;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.Inventory;

import java.net.URISyntaxException;

public interface InventoryService {
    Inventory getInventory(String businessGroupId, String tenantId, String sku) throws URISyntaxException;

    Inventory updateSingleInventory(String businessGroupId, String tenantId, SingleInventoryDto singleInventoryDto);

    Feed updateBulkInventory(String businessGroupId, String tenantId, String feedType, BulkInventoryDto bulkInventoryDto) throws URISyntaxException;
}
