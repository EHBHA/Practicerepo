package com.cloverbaylabs.nebula.oms.walmart.core.service.intf;

import com.cloverbaylabs.nebula.oms.walmart.schema.response.FeedErrorSummary;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.FeedStatus;

import java.net.URISyntaxException;

public interface FeedService {
    FeedStatus getAllFeedStatuses(String businessGroupId, String tenantId, String feedId, String feedType, String feedStatus, String offset, String limit) throws URISyntaxException;

    FeedErrorSummary getFeedErrorSummary(String businessGroupId, String tenantId, String feedId) throws URISyntaxException;
}
