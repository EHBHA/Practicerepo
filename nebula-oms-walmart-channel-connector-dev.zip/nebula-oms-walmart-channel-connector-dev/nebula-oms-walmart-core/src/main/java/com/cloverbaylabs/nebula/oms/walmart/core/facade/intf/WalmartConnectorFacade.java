package com.cloverbaylabs.nebula.oms.walmart.core.facade.intf;

import com.cloverbaylabs.nebula.oms.walmart.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.walmart.schema.enums.HttpMethod;
import com.fasterxml.jackson.databind.JsonNode;
import okhttp3.Headers;
import okhttp3.RequestBody;

import java.util.Map;

public interface WalmartConnectorFacade {
    <T> T walmartApiCall(ConnectorDetails connectorDetails, RequestBody requestBody,
                          Class<T> responseClass, String apiType);
}
