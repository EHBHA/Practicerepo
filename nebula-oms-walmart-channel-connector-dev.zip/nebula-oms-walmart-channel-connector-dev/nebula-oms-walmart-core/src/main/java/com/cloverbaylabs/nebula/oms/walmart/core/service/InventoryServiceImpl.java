package com.cloverbaylabs.nebula.oms.walmart.core.service;

import com.cloverbaylabs.nebula.oms.walmart.core.config.ConnectionEndpoints;
import com.cloverbaylabs.nebula.oms.walmart.core.facade.intf.WalmartConnectorFacade;
import com.cloverbaylabs.nebula.oms.walmart.core.service.intf.InventoryService;
import com.cloverbaylabs.nebula.oms.walmart.core.util.JsonConvertor;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.walmart.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.walmart.schema.inventory.dto.BulkInventoryDto;
import com.cloverbaylabs.nebula.oms.walmart.schema.inventory.dto.SingleInventoryDto;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.Feed;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.Inventory;
import lombok.RequiredArgsConstructor;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.cloverbaylabs.nebula.oms.walmart.core.util.UrlUtil.buildUrl;

@Service
@RequiredArgsConstructor
public class InventoryServiceImpl implements InventoryService {

    private static final String apiType = "Inventory";

    private final ConnectionEndpoints urls;

    private final WalmartConnectorFacade walmartConnectorFacade;

    private final JsonConvertor jsonConvertor;
    private static final String APPLICATION_JSON = "application/json";

    private final MediaType mediaTypeJson = MediaType.parse(APPLICATION_JSON);


    @Override
    public Inventory getInventory(String businessGroupId, String tenantId, String sku) throws URISyntaxException {
        Map<String, Object> params = new HashMap<>();
        params.put("sku", sku);

        String url = buildUrl(urls.getInventory(), params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .endpointUrl(url)
                .httpMethod(HttpMethod.GET)
                .acceptType(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .build();

        return walmartConnectorFacade.walmartApiCall(connectorDetails, null, Inventory.class, apiType);
    }

    @Override
    public Inventory updateSingleInventory(String businessGroupId, String tenantId, SingleInventoryDto singleInventoryDto) {

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .endpointUrl(urls.getInventory())
                .acceptType(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .httpMethod(HttpMethod.PUT)
                .build();

        String jsonPayload = jsonConvertor.convertToString(singleInventoryDto);
        RequestBody requestBody = RequestBody.create(jsonPayload, mediaTypeJson);

        return walmartConnectorFacade.walmartApiCall(connectorDetails, requestBody, Inventory.class, apiType);

    }

    @Override
    public Feed updateBulkInventory(String businessGroupId, String tenantId, String feedType, BulkInventoryDto bulkInventoryDto) throws URISyntaxException {

        Map<String, Object> params = new HashMap<>();
        params.put("feedType", feedType);

        String url = buildUrl(urls.getUpdateBulkInventory(), params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .endpointUrl(url)
                .httpMethod(HttpMethod.POST)
                .acceptType(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .build();

        String jsonPayload = jsonConvertor.convertToString(bulkInventoryDto);
        RequestBody requestBody = RequestBody.create(jsonPayload, mediaTypeJson);

        return walmartConnectorFacade.walmartApiCall(connectorDetails, requestBody, Feed.class, apiType);

    }
}
