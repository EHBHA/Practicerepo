package com.cloverbaylabs.nebula.oms.walmart.core.exception;

import com.cloverbaylabs.nebula.oms.walmart.schema.base.WalmartError;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.stereotype.Component;

@EqualsAndHashCode(callSuper = true)
@Data
@Component
public class WalmartApiException extends RuntimeException{

    private WalmartError walmartError;

    public WalmartApiException(){}

    public WalmartApiException(WalmartError walmartError){
        this.walmartError = walmartError;
    }

}
