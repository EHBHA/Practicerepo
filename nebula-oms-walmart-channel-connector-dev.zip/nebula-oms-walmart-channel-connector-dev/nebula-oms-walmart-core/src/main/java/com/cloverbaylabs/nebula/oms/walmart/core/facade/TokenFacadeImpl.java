package com.cloverbaylabs.nebula.oms.walmart.core.facade;

import com.cloverbaylabs.nebula.oms.walmart.core.config.ConnectionEndpoints;
import com.cloverbaylabs.nebula.oms.walmart.core.facade.intf.TokenFacade;
import com.cloverbaylabs.nebula.oms.walmart.core.service.intf.SecretManagerService;
//import com.cloverbaylabs.nebula.oms.walmart.core.util.HttpClientInvoker;
import com.cloverbaylabs.nebula.oms.walmart.core.util.HttpClientInvoker;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.AccessToken;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.Secret;
import com.cloverbaylabs.nebula.oms.walmart.schema.enums.HttpMethod;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.RequiredArgsConstructor;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
public class TokenFacadeImpl implements TokenFacade {

    private final HttpClientInvoker httpClientInvoker;

    private final SecretManagerService secretManagerService;

    private static final String CONTENT_TYPE = "application/x-www-form-urlencoded";

    private static final String GRANT_TYPE = "client_credentials";

    private static final String SERVICE_NAME = "";

    private static final String MARKET = "cl";

    private static final String apiType = "Authorization";

    private final ConnectionEndpoints urls;


    private final Cache<String, String> tokenCache = Caffeine.newBuilder()
            .expireAfterWrite(15, TimeUnit.MINUTES)
            .maximumSize(1)
            .build();

    private final Cache<String, Secret> secretCache = Caffeine.newBuilder()
            .expireAfterWrite(12, TimeUnit.HOURS)
            .build();

    @Override
    public Secret fetchSecret(String businessGroupId, String tenantId) {

        Secret cachedSecret = secretCache.getIfPresent(tenantId);
        if (cachedSecret != null) {
            return cachedSecret;
        }

        try {
            Secret secret = secretManagerService.getSecret(businessGroupId, tenantId);
            if (secret != null) {
                secretCache.put(tenantId, secret);
                return secret;
            }
            throw new RuntimeException("Client credentials not found");
        } catch (RuntimeException e) {
            throw new EntityNotFoundException("Client credentials not found");
        }
    }

    private String fetchNewToken(String businessGroupId, String tenantId) {
        Secret secret = fetchSecret(businessGroupId, tenantId);

        String credentials = secret.getClientId() + ":" + secret.getClientSecret();

        String authorizationCode = Base64.getEncoder()
                .encodeToString(credentials.getBytes(StandardCharsets.UTF_8));

        Headers headers = new Headers.Builder()
                .add("Authorization", "Basic " + authorizationCode)
                .build();

        String correlationId = UUID.randomUUID().toString();

        RequestBody formBody = new FormBody.Builder()
                .add("grant_type", GRANT_TYPE)
                .add("WM_MARKET", MARKET)
                .add("Content-Type", CONTENT_TYPE)
                .add("WM_QOS.CORRELATION_ID", correlationId)
                .add("WM_SVC.NAME", SERVICE_NAME)
                .build();


        try {
            AccessToken accessToken = httpClientInvoker.sendRequest(
                    HttpMethod.POST,
                    urls.getFetchAccessToken(),
                    headers,
                    formBody,
                    AccessToken.class,
                    apiType);

            if (accessToken != null) {
                tokenCache.put(tenantId, accessToken.getAccessToken());
                return accessToken.getAccessToken();
            }
            throw new RuntimeException("Failed to fetch access token: Empty response body");
        }catch (RuntimeException e){
            throw new RuntimeException("Failed to fetch access token: Empty response body");
        }
    }

    /**
     *
     * @param businessGroupId
     * @param tenantId
     * @return accessToken
     * @Description: The method returns accessToken from cache if it is not expired, if not it will fetch accessToken from api. The expiration time of accessToken is 15 minutes
     */
    @Override
    public String getAccessToken(String businessGroupId, String tenantId) {

        String token = tokenCache.getIfPresent(tenantId);
        if (token != null){
            return token;
        }
        return fetchNewToken(businessGroupId, tenantId);
    }
}
