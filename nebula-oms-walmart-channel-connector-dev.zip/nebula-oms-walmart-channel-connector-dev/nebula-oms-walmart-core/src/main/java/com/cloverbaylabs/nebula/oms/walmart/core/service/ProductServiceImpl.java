package com.cloverbaylabs.nebula.oms.walmart.core.service;

import com.cloverbaylabs.nebula.oms.walmart.core.config.ConnectionEndpoints;
import com.cloverbaylabs.nebula.oms.walmart.core.facade.intf.WalmartConnectorFacade;
import com.cloverbaylabs.nebula.oms.walmart.core.service.intf.ProductService;
import com.cloverbaylabs.nebula.oms.walmart.core.util.JsonConvertor;
import com.cloverbaylabs.nebula.oms.walmart.schema.base.ConnectorDetails;
import com.cloverbaylabs.nebula.oms.walmart.schema.enums.HttpMethod;
import com.cloverbaylabs.nebula.oms.walmart.schema.product.dto.ProductsDto;
import com.cloverbaylabs.nebula.oms.walmart.schema.product.dto.RetireItemDto;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.Feed;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.ProductsList;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.RetiredItem;
import com.cloverbaylabs.nebula.oms.walmart.schema.response.VariantGroupItemCount;
import lombok.RequiredArgsConstructor;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import static com.cloverbaylabs.nebula.oms.walmart.core.util.UrlUtil.buildUrl;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private static final String apiType = "Product";

    private final ConnectionEndpoints urls;

    private final JsonConvertor jsonConvertor;

    private final WalmartConnectorFacade walmartConnectorFacade;

    private static final String APPLICATION_JSON = "application/json";

    private final MediaType mediaTypeJson = MediaType.parse(APPLICATION_JSON);

    @Override
    public Feed createProduct(String businessGroupId, String tenantId, String feedType, ProductsDto productsDto) throws URISyntaxException {

        Map<String, Object> params = new HashMap<>();
        params.put("feedType", feedType);

        String url = buildUrl(urls.getCreateProduct(), params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.POST)
                .endpointUrl(url)
                .acceptType(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .build();

        String jsonPayload = jsonConvertor.convertToString(productsDto);
        RequestBody requestBody = RequestBody.create(jsonPayload, mediaTypeJson);

        return walmartConnectorFacade.walmartApiCall(connectorDetails, requestBody, Feed.class, apiType);
    }

    @Override
    public RetiredItem retireItem(String businessGroupId, String tenantId, RetireItemDto retireItemDto) {
        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.POST)
                .contentType(APPLICATION_JSON)
                .acceptType(APPLICATION_JSON)
                .endpointUrl(urls.getDeleteProduct())
                .build();

        String jsonPayload = jsonConvertor.convertToString(retireItemDto);
        RequestBody requestBody = RequestBody.create(jsonPayload, mediaTypeJson);

        return walmartConnectorFacade.walmartApiCall(connectorDetails, requestBody, RetiredItem.class, apiType);
    }

    @Override
    public ProductsList getOneItem(String businessGroupId, String tenantId, String sku, String productIdType) throws URISyntaxException {

        String baseUrl = urls.getSingleProduct() + "/" + sku;

        Map<String, Object> params = new HashMap<>();
        params.put("productIdType", productIdType);

        String url = buildUrl(baseUrl, params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .endpointUrl(url)
                .acceptType(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .build();

        return walmartConnectorFacade.walmartApiCall(connectorDetails, null, ProductsList.class, apiType);
    }

    @Override
    public ProductsList getAllItems(String businessGroupId, String tenantId) {
        return null;
    }

    @Override
    public VariantGroupItemCount getItemCountByVariant(String businessGroupId, String tenantId, String variantGroupId) throws URISyntaxException {
        Map<String, Object> params = new HashMap<>();
        params.put("variantGroupId", variantGroupId);

        String url = buildUrl(urls.getItemCountByGroup(), params);

        ConnectorDetails connectorDetails = ConnectorDetails.builder()
                .businessGroupId(businessGroupId)
                .tenantId(tenantId)
                .httpMethod(HttpMethod.GET)
                .acceptType(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .endpointUrl(url)
                .build();

        return walmartConnectorFacade.walmartApiCall(connectorDetails, null, VariantGroupItemCount.class, apiType);
    }


}
