package com.cloverbaylabs.nebula.oms.walmart.api.controller;


import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;


@RestController
@RequiredArgsConstructor
@RequestMapping("")
public class ProductController {

}
