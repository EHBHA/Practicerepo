package com.cloverbaylabs.nebula.oms.walmart.api.controller;

public class FeedController {
}
